# mobile_portal_front

> 移动端打包平台

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report

# run unit tests
npm run unit

# run e2e tests
npm run e2e

# run all tests
npm test
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).

## 结构

- 布局
- 导航栏目
- 页脚
- 面包线
- 打包首页


## 组件

- vue　负责数据处理和页面渲染
- vuex　某些场景用的数据中心处理器，类似redux
- vue-router　路由，无刷新跳转
- element-ui 饿了么ui组件库
- axio http请求库
- @xkeshi/vue-qrcode

> 尽量不要引入其他组件同等功能组件，jquery都没有引入，当然bootstrap也不会引入


## 首页后端接口

    测试地址   http://172.29.40.189:8989

### 获取bu list

    /lts/build/backend/mobile/mobilepackageinfos/get_bu_list/

>
    参数　　  示例
    
    app　    陆金所
    start　  2017-02-03
    end      2017-11-06

### 获取version list

    /lts/build/backend/mobile/mobilepackageinfos/get_version_list/

>
    参数　　  示例
    
    app　    陆金所
    bu       主App
    start　  2017-02-03
    end      2017-11-06
    
   
### 获取buildType list

    /lts/build/backend/mobile/mobilepackageinfos/get_build_type_list/

>
    参数　　  示例
    
    app　    陆金所
    bu       主App
    platform ios
    version  5.0.0
    start　  2017-02-03
    end      2017-11-06
    

### 获取build msg
    
    /lts/build/backend/mobile/mobilepackageinfos/get_package_build_param_and_git_info/

>
    参数　　  示例
    
    package_id　    123
    
    
### 锁定包----
  
    /lts/build/backend/mobile/mobilepackageinfos/<pk>
    

### 获取评论---

    /lts/build/backend/mobile/mobilepackagecomments/get_package_comments_and_islock/
    
>
    
    参数　　  示例
    
    package_id　    123
    
### 添加评论---    
> POST

    /lts/build/backend/mobile/mobilepackagecomments/
    
>
    
    参数　　  示例
    
    package_id　    123
    user_id       111
    comments      111

    
##　build页后端接口

### 获取build params -
    
    /lts/build/backend/mobile/mobilepackageinfos/get_package_build_parameter_by_build_id/

>
    参数　　  示例
    
    build_id　    123
