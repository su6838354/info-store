/**
 * Created by test on 18-1-12.
 */

import router from './router'
import store from './store'
import NProgress from 'nprogress' // Progress 进度条
import 'nprogress/nprogress.css'// Progress 进度条样式
// import { getToken } from './utils/auth' // 验权
import { api } from './api/const'

// const whiteList = ['/login', '/authredirect']// 不重定向白名单

router.beforeEach((to, from, next) => {
  NProgress.start() // 开启Progress
  /***
   * 判断登录, 乐观判断，不保证伪造
   */
  if (!store.getters['user/isLogin']) { // 判断当前用户是否已拉取完user_info信息
    /***
     * 没有登录
     */
    store.dispatch('user/getUserInfo').then(({is_login: isLogin, js_update: jsUpdate}) => { // 拉取user_info
      if (isLogin) {
        /***
         * 如果发版，需要强制更新页面
         */
        if (jsUpdate) {
          window.location.reload()
        } else {
          next()
        }
      } else {
        window.location.href = `${api.COMMON.LOGIN_IN}?next=${encodeURIComponent(window.location.href)}`
      }
    }).catch(() => {
      window.location.href = `${api.COMMON.LOGIN_IN}?next=${encodeURIComponent(window.location.href)}`
    })
  } else {
    /***
     * 登录了
     */
    next()
  }
})

router.afterEach(() => {
  NProgress.done() // 结束Progress
})
