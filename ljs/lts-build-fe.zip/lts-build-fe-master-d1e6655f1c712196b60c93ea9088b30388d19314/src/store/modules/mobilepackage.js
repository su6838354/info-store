/**
 * Created by test on 18-1-12.
 */

import moment from 'moment'
import types from '../mutation-types'
import mcApi from '../../api/mc-api'
import message from '../../utils/message'

const PACKAGE = types.PACKAGE

// let mobileParams = window.localStorage['mobile-build-search-params'] || `{}`
// mobileParams = JSON.parse(mobileParams)
// const { expired } = mobileParams
// if (moment(expired).add(1, 'days') < moment()) {
//   mobileParams = {}
// }
const mobileParams = {}

const { app, version, build_type, platform, build, display, begin_date: begin, end_date: end } = mobileParams

const mobilePackage = {
  namespaced: true,
  state: {
    package_list: [],
    params: {
      app,
      app_list: [],
      version,
      version_list: [],
      type_list: [],
      build_type,
      begin_date: begin || moment().subtract(7, 'days').format('YYYY-MM-DD'),
      end_date: end || moment().format('YYYY-MM-DD'),
      platform_list: [],
      platform,
      build: build || 'all',
      display: display || 'all',
      display_list: [
        {name: '所有包', value: 'all'},
        {name: '正式包', value: 'normal'},
        {name: '特殊包', value: 'special'},
        {name: '回归包', value: 'regression'}
      ]
    },
    loading: false
  },
  getters: {
    package_list (state) {
      return state.package_list
    },
    params (state) {
      return state.params
    },
    loading (state) {
      return state.loading
    }
  },
  mutations: {
    [PACKAGE.UPDATE_PARAMS] (state, params) {
      state.params = {...state.params, ...params}
    },
    [PACKAGE.UPDATE_PACKAGE_LIST] (state, packageList) {
      state.package_list = packageList.slice()
    },
    [PACKAGE.LOADING_TABLE] (state, loading) {
      state.loading = loading
    },
    [PACKAGE.UPDATE_LOCK_STATUS] (state, { lock_status: lockStatus, package_id: packageId }) {
      state.package_list.filter(item => item.id === packageId)[0].lock_status = lockStatus
    }
  },
  /***
   * store.dispatch('increment')
   *
   */
  actions: {
    // getPackageList ({ commit, getters, dispatch }) {
    //   const {begin_date, end_date} = getters.params
    //   mcApi.getPackage({ begin_date, end_date }).then(({ data, code, message }) => {
    //     if (code === 0) {
    //       const {params, package_list} = data
    //       commit(PACKAGE.UPDATE_PARAMS, params)
    //       commit(PACKAGE.UPDATE_PACKAGE_LIST, package_list)
    //     }
    //   })
    // },
    fetchPackageList ({commit, getters}) {
      commit(PACKAGE.LOADING_TABLE, true)
      const {app, version, platform, build_type, build, display, begin_date, end_date} = getters.params
      mcApi.getPackage({ app, version, platform, build_type, build, display, begin_date, end_date })
        .then(({ data, code, message }) => {
          if (code === 0) {
            const {params, package_list} = data
            commit(PACKAGE.UPDATE_PARAMS, {...params, type: params.build_type})
            commit(PACKAGE.UPDATE_PACKAGE_LIST, package_list)
            // setTimeout(() => {
            //   window.localStorage['mobile-build-search-params'] = JSON.stringify({...getters.params, expired: moment()})
            // }, 500)
          }
        })
        .finally(() => {
          commit(PACKAGE.LOADING_TABLE, false)
        })
    },
    updateAppList ({commit, getters}) {
      const {params} = getters
      mcApi.getAppList({start: params.begin_date, end: params.end_date}).then(({ data }) => {
        commit(PACKAGE.UPDATE_PARAMS, {app_list: data})
      })
    },
    updateVersionList ({commit, getters}) {
      const {params} = getters
      mcApi.getVersionList({app: params.app, platform: params.platform, start: params.begin_date, end: params.end_date})
        .then(({ data }) => {
          const update = {version_list: data}
          if (data.filter(item => item === getters.params.version).length === 0) {
            update['version'] = undefined
          }
          commit(PACKAGE.UPDATE_PARAMS, update)
        })
    },
    updateBuildTypeList ({commit, getters}) {
      const {params} = getters
      mcApi.getBuildTypeList({
        app: params.app,
        platform: params.platform,
        version: params.version,
        start: params.begin_date,
        end: params.end_date
      }).then(({ data }) => {
        const update = {type_list: data}
        if (data.filter(item => item === getters.params.build_type).length === 0) {
          update['build_type'] = undefined
        }
        commit(PACKAGE.UPDATE_PARAMS, update)
      })
    },
    setPackageLocked ({commit}, {package_id, lock_status}) {
      mcApi.setPackageLocked(package_id, { lock_status }).then(({data, code, message: msg}) => {
        if (code === 0) {
          commit(PACKAGE.UPDATE_LOCK_STATUS, {package_id, lock_status})
          message.success(msg)
        }
      })
    }
  }
}

export default mobilePackage
