/**
 * Created by test on 18-1-16.
 */

import mcApi from '../../api/mc-api'
import types from '../mutation-types'
import message from '../../utils/message'

const BUILD = types.BUILD

const mobileBuild = {
  namespaced: true,
  state: {
    // build_list: [],
    // pagination: {},
    // loading: false,
    build_info: {
      app: null,
      bu: null,
      platform: null,
      type: null,
      version: null,
      regression: false,
      versionList: [],
      appList: [],
      buList: [],
      platformList: [],
      buildTypeList: [],
      is_need_upload_pgy: false
    },
    url: '',
    build_param: [],
    rebuild_param_value: {},
    activeNames: [],
    detailParamsSuccess: false
  },
  getters: {
    build_param (state) {
      return state.build_param
    },
    build_info (state) {
      return state.build_info
    },
    rebuild_param_value (state) {
      return state.rebuild_param_value
    },
    activeNames (state) {
      return state.activeNames
    },
    actionType (state) {
      return state.actionType
    },
    detailParamsSuccess (state) {
      return state.detailParamsSuccess
    }
  },
  mutations: {
    [BUILD.UPDATE_BUILD_PARAM] (state, data) {
      state.build_param = data
    },
    [BUILD.UPDATE_BUILD_INFO] (state, data) {
      state.build_info = {...state.build_info, ...data}
    },
    [BUILD.UPDATE_URL] (state, url) {
      state.url = url
    },
    [BUILD.UPDATE_REBUILD_PARAM_VALUE] (state, paramValue) {
      state.rebuild_param_value = paramValue
    },
    [BUILD.UPDATE_ACTIVE_NAMES] (state, value) {
      state.activeNames = value
    },
    updateGetBuildParamsSuccess (state, value) {
      state.detailParamsSuccess = value
    }
  },
  actions: {
    async getBuildParams ({ getters, commit, dispatch }) {
      commit('updateGetBuildParamsSuccess', false)
      const { app, bu, platform, type, version, regression } = getters.build_info
      const buildParams = { app, bu, platform, type, version, regression }

      // 检查一下，quick build的时候，如果version不是x.x.x格式，提示用户
      const reg = /^\d\.\d\.\d$/g
      if (!reg.test(version)) {
        const ok = await message.confirm(`您输入的版本为：${version},请确认！`)
        if (!ok) {
          return null
        }
      }

      const { data, code } = await mcApi.getBuildParams(buildParams)
      let {params, url, relation_detail} = data
      if (code === 0) {
        const regRegex = /^\s*Reg_(\d\.){2}\d(\.\d)?\s*$/
        const regex = /^\s*DEV_(\d\.){2}\d(\.\d)?\s*$/
        const rebuildParamValue = getters.rebuild_param_value
        params = params.map(item => {
          if (item.name in rebuildParamValue) {
            item.defaultParameterValue.value = rebuildParamValue[item.name]
          }
          if (item.name === 'version') {
            item.defaultParameterValue.value = version
            item.disable = true
          } else if (regression && item.name === 'android_branch') {
            item.defaultParameterValue.value = `Reg_${version.replace(/\./g, '')}`
          } else if (regex.exec(item.defaultParameterValue.value)) {
            // 满足DEV_3.5.5 格式的，进行版本号替换
            item.defaultParameterValue.value = `DEV_${version}`
          } else if (regRegex.exec(item.defaultParameterValue.value)) {
            item.defaultParameterValue.value = `Reg_${version}`
          } else if (params.platform === 'ios' && item.name === 'channel') {
            // 小补丁。当ios打包时，如果有channel字段，则用全局的type替换之
            item.defaultParameterValue.value = params.type
            item.disable = true
          }
          return item
        })
        /**
         * 当jenkins_job_build_type_param_name值存在时候，用type的值替换对应值
         */
        if (relation_detail.jenkins_job_build_type_param_name != null) {
          const item = params.filter(item => item.name === relation_detail.jenkins_job_build_type_param_name)[0]
          item.defaultParameterValue.value = getters.build_info.type
          item.disable = true
        }
        commit(BUILD.UPDATE_BUILD_PARAM, params)
        commit(BUILD.UPDATE_URL, url)
        commit('updateGetBuildParamsSuccess', true)
        return true
      }
    },

    async startBuild ({ commit, getters, dispatch, state }) {
      const {app, bu, version, platform, type, regression, is_need_upload_pgy: isNeed} = getters.build_info
      if (platform === 'android' && regression) {
        const ok = await message.confirm('构建回归包时，请确认是否有相应Reg分支?')
        if (!ok) {
          return null
        }
      }
      const {build_param: buildParam} = getters
      const buildParamForm = buildParam.map(item => {
        return {name: item.name, value: item.defaultParameterValue.value}
      })
      const data = {
        build_info_json: JSON.stringify({
          app, bu, version, platform, type, regression, url: state.url, is_need_upload_pgy: isNeed ? 1 : 0
        }),
        build_param_json: JSON.stringify(buildParamForm)
      }
      return mcApi.postBuild(data).then(({ data, code }) => {
        if (code === 0) {
          message.success('构建已成功触发')
          return true
        }
      })
    },
    stopBuild ({ commit }, buildId) {
      return mcApi.stopBuild({build_info_id: buildId}).then(({code, message: msg}) => {
        if (code === 0) {
          message.success(msg)
        } else {
          message.error(`终止job失败。请刷新页面后重试。${msg}`)
        }
      })
    },
    async toRebuild ({ commit, getters, dispatch }, buildInfo) {
      const {APP: app, BU: bu, platform, type, version, id} = buildInfo
      commit(BUILD.UPDATE_BUILD_INFO, {app, bu, platform, type, version})
      const ok = dispatch('getBuildParamsById', id)
      if (ok) {
        const ok2 = dispatch('getBuildParams')
        if (ok2) {
          commit(BUILD.UPDATE_ACTIVE_NAMES, '1')
          message.info(`构建参数已设置为${id}的构建参数,确认无误后执行<strong>开始构建</strong>`)
        }
      }
    },
    async getBuildParamsById ({ commit }, buildInfoId) {
      const {code, data} = await mcApi.getBuildParamsById({build_info_id: buildInfoId})
      if (code === 0) {
        commit(BUILD.UPDATE_REBUILD_PARAM_VALUE, data)
        return true
      }
    },

    /**
     * 处理build params
     * @param commit
     * @returns {Promise.<void>}
     */
    async getDistApps ({ commit }) {
      const {code, data} = await mcApi.getDistApps()
      if (code === 0) {
        commit(BUILD.UPDATE_BUILD_INFO, {appList: data})
      }
    },
    async getDistBus ({ commit, getters }) {
      const {code, data} = await mcApi.getDistBus({app: getters.build_info.app})
      if (code === 0) {
        commit(BUILD.UPDATE_BUILD_INFO, {
          bu: undefined,
          buList: data,
          platform: undefined,
          platformList: [],
          type: undefined,
          buildTypeList: [],
          version: undefined,
          versionList: []
        })
      }
    },
    async getDistPlatforms ({ commit, getters }) {
      const {code, data} = await mcApi.getDistPlatforms({app: getters.build_info.app, bu: getters.build_info.bu})
      if (code === 0) {
        commit(BUILD.UPDATE_BUILD_INFO, {
          platform: undefined,
          platformList: data,
          type: undefined,
          buildTypeList: [],
          version: undefined,
          versionList: []
        })
      }
    },
    async getDistBuildTypeList ({ commit, getters }) {
      const {code, data} = await mcApi.getDistBuildTypes({
        app: getters.build_info.app,
        bu: getters.build_info.bu,
        platform: getters.build_info.platform
      })
      if (code === 0) {
        commit(BUILD.UPDATE_BUILD_INFO, {
          type: undefined,
          buildTypeList: data,
          version: undefined,
          versionList: []
        })
      }
    },
    async getRecentBuildVersion ({ commit, getters }) {
      const {code, data} = await mcApi.getRecentBuildVersion({
        app: getters.build_info.app,
        bu: getters.build_info.bu,
        platform: getters.build_info.platform,
        build_type: getters.build_info.type
      })
      if (code === 0) {
        commit(BUILD.UPDATE_BUILD_INFO, {
          version: undefined,
          versionList: data
        })
      }
    }
  }
}

export default mobileBuild
