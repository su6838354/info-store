/**
 * Created by test on 18-1-12.
 */

import userApi from '../../api/user'
import { getToken } from '../../utils/auth'
import message from '../../utils/message'

const user = {
  namespaced: true,
  state: {
    userName: 'suyuan550',
    status: '',
    isLogin: false,
    code: 0,
    token: getToken(),
    avatar: '',
    introduction: '',
    roles: [],
    setting: {
      articlePlatform: []
    }
  },
  mutations: {
    CLEAR (state) {
      state.isLogin = false
    },
    SET_USER_INFO (state, {isLogin, userName}) {
      state.isLogin = isLogin
      state.userName = userName
    }
  },
  getters: {
    isLogin (state) {
      return state.isLogin
    },
    userName (state) {
      return state.userName
    }
  },

  actions: {
    // 获取用户信息
    getUserInfo ({ commit, state }) {
      const params = {}
      if (process.env.NODE_ENV === 'production') {
        const scripts = window.document.querySelector('script[src*="/lts/build/static/js/app"]')
        const src = scripts.getAttribute('src')
        params['version'] = src.substr(src.indexOf('app.') + 4, src.length - src.indexOf('app.') - 7)
      }
      return userApi.getUserInfo(params).then(({code, data}) => {
        if (code === 0) {
          const {is_login: isLogin, username: userName} = data
          if (isLogin) {
            commit('SET_USER_INFO', {isLogin, userName})
            const delay = 1000 * 60 * 30 // 缓存30分钟自动清除状态，重新check
            setTimeout(() => {
              commit('SET_USER_INFO', {isLogin: false, userName: null})
            }, delay)
          }
        }
        return data
      })
    },
    async loginOut ({ commit }) {
      const ok = await message.confirm(`确认登出！`)
      if (ok) {
        commit('CLEAR')
      }
      return ok
    }
  }
}

export default user
