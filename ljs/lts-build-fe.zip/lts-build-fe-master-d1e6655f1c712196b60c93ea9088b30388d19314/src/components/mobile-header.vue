<template>
  <el-header >
    <el-menu
      :default-active="$route.path"
      class="el-menu-demo"
      mode="horizontal"
      background-color="#34495e"
      text-color="#fff"
      active-text-color="#ffd04b">
      <el-menu-item index="-1">
        <img src="http://lujs.cn/lts/mc/img/logo_50.png" />
        <a class="menu-brand" href="#">LuMC 移动云测平台</a>
      </el-menu-item>
      <template v-for="(value, key, index)  in menuList">
        <el-submenu v-if="value.list" :index="`${key}`" :key="key">
            <template slot="title">
              <router-link class="sub-menu-title" v-if="isInner(value.href)" :to="value.href">{{value.text}}</router-link>
              <a v-else class="sub-menu-title" :href="value.href">{{value.text}}</a>
            </template>

            <template v-for="(sub_value, sub_key) in value.list" >
              <router-link v-if="isInner(sub_value.href)" class="sub-menu-title" :to="sub_value.href">
                <el-menu-item :index="sub_value.href" :key="`${key}-${sub_key}`">
                  {{sub_value.text}}
                </el-menu-item>
              </router-link>

              <a v-else class="sub-menu-title" :href="sub_value.href">
                <el-menu-item :index="sub_value.href" :key="`${key}-${sub_key}`" >
                {{sub_value.text}}
                </el-menu-item>
              </a>
            </template>

        </el-submenu>

        <el-menu-item v-else :index="`${key}`" :key="key">
          <a :href="value.href">{{value.text}}</a>
        </el-menu-item>
      </template>

      <el-submenu id="menu-user" :index="'99'" key="99">
        <template slot="title">
          欢迎：{{userName}}
        </template>

          <a :href="loginInUrl">
            <el-menu-item v-if="!isLogin" :key="loginInUrl" :index="loginInUrl">登录</el-menu-item>
          </a>

          <a :href='accountUrl'>
            <el-menu-item v-if="isLogin" :key="accountUrl" index="accountUrl">查看我的账户</el-menu-item>
          </a>

          <a @click="loginOutWarp" >
            <el-menu-item v-if="isLogin" :key="loginOutUrl" index="loginOutUrl">登出</el-menu-item>
          </a>
      </el-submenu>
    </el-menu>
  </el-header>
</template>

<script>
  import mcApi from '../api/mc-api'
  import { api } from '../api/const'
  import { createNamespacedHelpers } from 'vuex'
  const { mapGetters, mapActions } = createNamespacedHelpers('user')

  export default {
    name: 'MobileHeader',
    data () {
      return {
        menuList: [],
        loginOutUrl: api.COMMON.LOGIN_OUT,
        loginInUrl: api.COMMON.LOGIN_IN,
        accountUrl: api.COMMON.ACCOUNT
      }
    },
    created: function () {
      this.getHeaderList()
//      this.$nextTick(function () {
//      })
    },
    computed: {
      ...mapGetters({
        isLogin: 'isLogin',
        userName: 'userName'
      })
    },
    methods: {
      ...mapActions({
        loginOut: 'loginOut'
      }),
      loginOutWarp () {
        this.loginOut().then((ok) => {
          if (ok) {
            window.location.href = this.loginOutUrl
          }
        })
      },
      isInner (href) {
        return (href.indexOf('http') === -1)
      },
      getHeaderList: function () {
        const vm = this
        mcApi.getHeader().then(({code, data}) => {
          if (code === 0) {
            vm.menuList = data.data.menuList
          }
        })
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  header{
    background-color: #34495e;
    font-weight: 700;
    /*height: 53px !important;*/
  }

  .menu-brand{
    font-size: 24px;
  }
  .is-active{
    color: white !important;
    border-bottom-color: rgb(52, 73, 94) !important;
    background-color: #1abc9c !important;
  }
  .el-menu-item{
    /*height: 53px;*/
  }
  .el-submenu{
    /*height: 53px;*/
  }


  .sub-menu-title{
    color: white;
    width: 100%;
  }
  #menu-user {
    float: right;
  }

  a{
    color: white;
    text-decoration: blink;
  }

</style>
<style>
  .is-active .el-submenu__title {
    color: white !important;
    border-bottom-color: rgb(52, 73, 94) !important;
    background-color: #1abc9c !important;
  }
  .el-submenu__title{
    /*height: 53px !important;*/
  }
</style>
