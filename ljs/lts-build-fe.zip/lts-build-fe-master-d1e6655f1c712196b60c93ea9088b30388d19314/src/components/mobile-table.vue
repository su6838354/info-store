<template>
  <div>
    <el-table
      :data="tableData"
      stripe
      v-loading="loading"
      :default-sort = "{prop: 'id', order: 'descending'}"
    >
      <slot></slot>
    </el-table>

    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :page-sizes="[10, 20, 50, 500]"
      :page-size="pageSize"
      background
      layout="total, sizes, prev, pager, next, jumper"
      :total="total">
    </el-pagination>
  </div>
</template>

<script>
export default {
  name: 'MobileTable',
  props: ['rawData', 'loading'],
  data () {
    return {
      currentPage: 1,
      pageSize: 10
    }
  },
  computed: {
    tableData () {
      const start = (this.currentPage - 1) * this.pageSize
      const end = start + this.pageSize
      return this.rawData.slice(start, end)
    },
    total () {
      return this.rawData.length
    }
  },
  methods: {
    handleSizeChange (size) {
      this.pageSize = size
    },
    handleCurrentChange (currentPage) {
      this.currentPage = currentPage
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .el-pagination {
    float: right;
    margin-top: 1rem;
  }

</style>
