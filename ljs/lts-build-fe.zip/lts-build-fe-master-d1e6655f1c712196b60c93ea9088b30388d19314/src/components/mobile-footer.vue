<template>
  <div class="mobile-footer">
    <p><h3>陆金所测试部 版权所有</h3></p>
    <p>如有任何改进建议，bug，需求等请联系：</p>
    <p>@于乐怡 yuleyi799@lu.com @苏远 suyuan550@lu.com</p>
  </div>
</template>

<script>
export default {
  name: 'mobile-footer',
  data () {
    return {

    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .mobile-footer{
    text-align: center;
  }

</style>
