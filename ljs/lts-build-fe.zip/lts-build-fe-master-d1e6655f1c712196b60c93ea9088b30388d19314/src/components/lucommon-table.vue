<template>
  <div>
    <el-form @submit.native.prevent ref="searchForm" :inline="true" :model="searchData" >
      <slot name="filters" :searchData="searchData" ></slot>
      <el-form-item>
        <el-button type="primary" @click="onSubmit">查询</el-button>
      </el-form-item>
    </el-form>

    <el-button style="float: right" icon="el-icon-refresh" round　@click="fetchData">刷新</el-button>
    <el-table
      :data="rawData"
      stripe
      v-loading="loading"
      :row-class-name="tableRowClassName"
      @row-click="rowClick"
    >
      <slot></slot>
    </el-table>

    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :page-sizes="[10, 20, 50, 500]"
      :page-size="pageSize"
      background
      layout="total, sizes, prev, pager, next, jumper"
      :total="total">
    </el-pagination>
  </div>
</template>

<script>
  import request from '../utils/request'
  export default {
    name: 'LucommonTable',
    props: ['url'],
    data () {
      return {
        currentPage: 1,
        pageSize: 10,
        total: 0,
        rawData: [],
        loading: false,
        activeId: 0,
        searchData: {
        }
      }
    },
    created () {
      this.fetchData()
    },
    computed: {

    },
    watch: {
      currentPage: function () {
        this.fetchData()
      },
      pageSize: function () {
        this.currentPage = 1
        this.fetchData()
      }
    },
    methods: {
      onSubmit () {
        this.$refs['searchForm'].validate((valid) => {
          if (valid) {
            this.fetchData()
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      rowClick (row, event, column) {
        this.activeId = row.id
      },
      tableRowClassName ({ row, rowIndex }) {
        if (row.id === this.activeId) {
          return 'lu-active-row'
        }
        return ''
      },
      handleSizeChange (size) {
        this.pageSize = size
      },
      handleCurrentChange (currentPage) {
        this.currentPage = currentPage
      },
      fetchData () {
        this.loading = true
        /**
         * 分页
         * @type {{lu_limit: *, lu_offset: number, lu_order_field: string}}
         */
        const params = {
          lu_limit: this.pageSize,
          lu_offset: (this.currentPage - 1) * this.pageSize,
          lu_order_field: '-id'
        }
        /**
         * 查询
         * @type {{lu_search_field: Array, lu_search_word: Array, lu_search_type: Array}}
         */
        const searchParams = {
          lu_search_field: [],
          lu_search_word: [],
          lu_search_type: []
        }
        for (const field in this.searchData) {
          if (Object.prototype.hasOwnProperty.call(this.searchData, field)) {
            const data = this.searchData[field]
            searchParams.lu_search_field.push(field)
            searchParams.lu_search_word.push(data)
            searchParams.lu_search_type.push(0)
          }
        }

        params.lu_search_field = searchParams.lu_search_field.join(',')
        params.lu_search_word = searchParams.lu_search_word.join(',')
        params.lu_search_type = searchParams.lu_search_type.join(',')

        /**
         * 请求
         */
        request({
          url: this.url,
          method: 'get',
          params
        }).then(({ code, data, pagination }) => {
          if (code === 0) {
            this.rawData = data
            this.total = pagination.count
          }
        }).finally(() => {
          this.loading = false
        })
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
<style>
  .el-table .lu-active-row {
    font-weight: 600;
  }
  .el-pagination {
    float: right;
    margin-top: 1rem;
  }


</style>
