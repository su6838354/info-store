<template>
  <div class="input-group">
    <span class="input-group-addon filter-title">
        <label>
            {{label}}：
        </label>
    </span>
    <span v-for="item in data" class="input-group-addon filter-context">
      <label>
          <input :name="name" :value="item" type="radio" :checked="item==value" @click="onChange"> {{item}}
      </label>
    </span>
  </div>
</template>

<script>
export default {
  data () {
    return {
    }
  },
  methods: {
    onChange ($event) {
      this.$emit('update:value', $event.target.value)
      this.$emit('change', $event.target.value)
    }
  },
  props: ['data', 'value', 'label', 'name']
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
