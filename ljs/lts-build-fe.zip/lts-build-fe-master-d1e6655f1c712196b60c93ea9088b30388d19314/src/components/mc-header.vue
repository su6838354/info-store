<template>
  <nav class="navbar navbar-style navbar-embossed"  role="navigation">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-01"">
        <span class="sr-only">Toggle navigation</span>
        </button>
        <a class="navbar-brand" href="#">LuMC 移动云测平台</a>
      </div>
      <div class="collapse navbar-collapse" id="navbar-collapse-01">
        <ul class="nav navbar-nav">
          <template v-for="header in headerList">
            <li v-if="!header.list" :class="{active:header.text==defaultActive}" >
              <a v-if="header.full==true" :target="header.target_blank?'_blank':''" :href="header.href" v-text="header.text"></a>
              <a v-else :href="header.href" :target="header.target_blank?'_blank':''" v-text="header.text"></a>
            </li>
            <control-dropdown v-else="header.list"
                              :class="{active:header.text==defaultActive}"
                              v-bind:items="header"
                              v-bind:isli="true">
            </control-dropdown>
          </template>
        </ul>
        <p class="navbar-text navbar-right dropdown" :class="{open:showMy}" @mouseenter="showMy=true" @mouseleave="showMy=false">欢迎：
          <a class="navbar-link" href="#" >{{user}}<span class="caret"></span></a>
        <ul v-if="user!='游客'" class="dropdown-menu">
          <li>
            <a href='http://lujs.cn/lts/mc/my/account.html'>查看我的账户</a>
          </li>
          <li role="separator" class="divider"></li>
          <li>
            <a :href="context+'/admin/caslogout'">登出</a>
          </li>
        </ul>
        <ul v-else class="dropdown-menu">
          <li>
            <a :href="context+'/admin/login'">登录</a>
          </li>
        </ul>
        </p>
      </div>
    </div>
  </nav>
</template>

<script>
  import controlDropdown from './control-dropdown.vue'
  import mcApi from '../api/mc-api'
  const CONTEXT = 'lujs.cn/mobile'

  export default {
    name: 'mc-header',
    data () {
      return {
        headerList: [],
        userList: [],
        showMy: false,
        context: CONTEXT
      }
    },
    created: function () {
      this.getHeaderList()
//      this.$nextTick(function () {
//      })
    },
    props: {
      defaultActive: {default: '工作台'},
      user: {default: '游客'}
    },
    methods: {
      getHeaderList: function () {
        const _this = this
        mcApi.getHeader().then(res => {
          _this.headerList = res.data
        })
      }
    },
    components: {
      controlDropdown
      // "control-dropdown": DropDown
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
