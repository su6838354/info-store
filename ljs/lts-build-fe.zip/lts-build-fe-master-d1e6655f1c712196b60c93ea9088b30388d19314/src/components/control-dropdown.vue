<template>
  <li v-if="isli" class="dropdown" @mouseenter="isShowChoose=true" :class="{open:isShowChoose}" @mouseleave="isShowChoose=false">
    <a :href="items.href=='#'?'#':items.href" class="dropdown-toggle" data-toggle="dropdown">
      {{items.text}}
      <span class="caret"></span>
    </a>
    <span v-if="isUnderRead" class="navbar-unread">1</span>
    <ul class="dropdown-menu" role="menu">
      <li v-for="(item,index) in items.list">
        <a :href="item.href=='#'?'#':item.href"> {{item.text}}
          <!--unread 现在有bug。默认是为nav设计，如果想添加在普通的li上，需要相应修改css-->
          <!--<span v-if="item.unread>0" class="navbar-new" v-text="item.unread"></span>-->
        </a>
      </li>
    </ul>
  </li>
  <div v-else class="dropdown" @mouseenter="isShowChoose=true" :class="{open:isShowChoose}" @mouseleave="isShowChoose=false">
    <button class="btn dropdown-toggle" :class="classObject" type="button" data-toggle="dropdown" >
      <span v-text="items.text"></span><span class="caret"></span>
    </button>
    <ul class="dropdown-menu" role="menu">
      <li v-for="(item,index) in items.list"><a :href="item.href" v-text="item.text"></a></li>
    </ul>
  </div>
</template>

<script>
  const CONTEXT = 'lujs.cn/mobile'
  export default {
    name: 'control-dropdown',
    data () {
      return {
        // 是否显示下拉内容
        isShowChoose: false,
        // 默认的选项
        defaultChoose: {},
        // 点击选中的项
        selectItem: {},
        // context
        context: CONTEXT
      }
    },
    props: {
      // 传入的菜单内容，格式：[{text:"abc",value:"1",href:"#",unread:6}]
      items: {default: {}},
      // 是否是li， true代表导航项。false代表是普通按钮下拉菜单
      isli: {default: false},
      // 按钮的样式
      classObject: {default: 'btn-style '},
      // 是否在右侧显示未读标识
      isUnderRead: {default: false},
      // li 时候使用，默认的显示文本
      defaultText: {default: ''}
      // To Do 添加下拉菜单的选择事件
    },
    mounted: function () {
      var _this = this
      this.$nextTick(function () {
        _this.items.list.forEach(function (item) {
          if (item.default) {
            _this.defaultChoose = item
          }
        })
      })
    },
    methods: {
      // To Do
      // 按钮的点击事件
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
