/**
 * Created by test on 17-12-21.
 */

import request from '../utils/request'
// import axios from 'axios'
import { api } from './const'
import qs from 'qs'
import mcMock from '../../mock/data/mc'

export default {
  getBuildMsg (params) {
    return request({
      url: api.MC.GET_BUILD_MSG,
      method: 'get',
      params
    })
  },

  getBuList (params) {
    return request({
      url: api.MC.GET_BU_LIST,
      method: 'get',
      params
    })
  },

  getVersionList (params) {
    return request({
      url: api.MC.GET_VERSION_LIST,
      method: 'get',
      params
    })
  },

  getBuildTypeList (params) {
    return request({
      url: api.MC.GET_BUILD_TYPE_LIST,
      method: 'get',
      params
    })
  },

  /***
   *
   * @param packageId
   * @param data: {lock_status}
   * @returns {AxiosPromise<T>}
   */
  setPackageLocked (packageId, data) {
    return request({
      url: `${api.MC.SET_PACKAGE_LOCK}${packageId}`,
      method: 'patch',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      data: qs.stringify(data)
    })
  },

  getPackageCommentsLock (params) {
    return request({
      url: api.MC.GET_COMMENTS_LOCK,
      method: 'get',
      params
    })
  },

  /***
   *
   * @param data: {package_id, user_id, comments}
   * @returns {AxiosPromise<T>}
   */
  addComments (data) {
    return request({
      url: api.MC.ADD_COMMENTS,
      method: 'post',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      data: qs.stringify(data)
    })
  },

  deleteComments (commentId) {
    return request({
      url: api.MC.ADD_COMMENTS + commentId,
      method: 'delete'
    })
  },

  /***
   *
   * @param params: {package_id}
   * @returns {AxiosPromise<T>}
   */
  getGeneralTest (params) {
    return request({
      url: api.MC.GET_GENERAL_TEST_INFO,
      method: 'get',
      params
    })
  },

  /***
   *
   * @param params
   */
  getBuildInfo (params) {
    return request({
      url: api.MC.GET_BUILD_INFO,
      method: 'get',
      params
    })
  },

  /***
   *
   * @param params: {app, bu, platform, version, build_type, build, platform, display, package_id, begin_date, end_date}
   * @returns {*}
   */
  getPackage (params) {
    return request({
      url: api.MC.GET_INDEX_INFO,
      method: 'get',
      params
    })
  },

  /***
   *
   * @param params: {start, end}
   * @returns {AxiosPromise<T>}
   */
  getAppList (params) {
    return request({
      url: api.MC.GET_APP_LIST,
      method: 'get',
      params
    })
  },

  // ----- build -----

  // getBuildInfoData (params) {
  //   return request({
  //     url: api.BUILD.GET_BUILD_INFO_DATA,
  //     method: 'get',
  //     params: {...params, lu_order_field: '-id'}
  //   })
  // },

  /***
   *
   * @param params: {app, bu, platform, type, version}
   * @returns {AxiosPromise<T>}
   */
  getBuildParams (params) {
    return request({
      url: api.BUILD.GET_BUILD_INFO,
      method: 'get',
      params
    })
  },

  /***
   *
   * @param data: {build_info_json, build_param_json}
   * @returns {AxiosPromise<T>}
   */
  postBuild (data) {
    return request({
      url: api.BUILD.POST_BUILD,
      method: 'post',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      data: qs.stringify(data)
    })
  },

  stopBuild (data) {
    return request({
      url: api.BUILD.STOP_BUILD,
      method: 'post',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      data: qs.stringify(data)
    })
  },

  /***
   *
   * @param params: {build_info_id}
   * @returns {AxiosPromise<T>}
   */
  getBuildParamsById (params) {
    return request({
      url: api.BUILD.GET_BUILD_INFO_BY_ID,
      method: 'get',
      params
    })
  },

  getDiffs (params) {
    return request({
      url: api.BUILD.GET_DIFFS,
      method: 'get',
      params
    })
  },

  getDistApps () {
    return request({
      url: api.BUILD.GET_DIST_APPS,
      method: 'get'
    })
  },

  /**
   *
   * @param params: {app}
   * @returns {AxiosPromise<T>}
   */
  getDistBus (params) {
    return request({
      url: api.BUILD.GET_DIST_BUS,
      method: 'get',
      params
    })
  },

  /**
   *
   * @param params: {app, bu}
   * @returns {AxiosPromise<T>}
   */
  getDistPlatforms (params) {
    return request({
      url: api.BUILD.GET_DIST_PLATFORMS,
      method: 'get',
      params
    })
  },

  /**
   *
   * @param params: {app, bu, platform}
   * @returns {AxiosPromise<T>}
   */
  getDistBuildTypes (params) {
    return request({
      url: api.BUILD.GET_DIST_BUILD_TYPES,
      method: 'get',
      params
    })
  },

  getRecentBuildVersion (params) {
    return request({
      url: api.BUILD.GET_RECENT_BUILD_VERSION,
      method: 'get',
      params
    })
  },
  // -------
  getHeader () {
    return new Promise((resolve, reject) => {
      resolve({
        code: 0,
        message: 'success',
        data: mcMock.headers
      })
    })
    // return axios.get(api.MC.GET_HEADERS).then(response => {
    //   return response.data
    // })
  }
}
