/**
 * Created by test on 17-12-21.
 */

function serverUrl (item) {
  return `${window.location.origin}/lts/build/backend/${item}`
}

function mobileServerUrl (item) {
  return `${window.location.origin}/lts/build/backend/mobile/${item}`
}

function mockUrl (item) {
  return `http://172.29.41.203:8080/api/v1${mockUrl}${item}`
}

export const api = {
  MC: {
    GET_BU_LIST: mobileServerUrl('mobilepackageinfos/get_bu_list/'),
    GET_VERSION_LIST: mobileServerUrl('mobilepackageinfos/get_version_list/'),
    GET_BUILD_TYPE_LIST: mobileServerUrl('mobilepackageinfos/get_build_type_list/'),
    SET_PACKAGE_LOCK: mobileServerUrl('mobilepackageinfos/'),
    GET_BUILD_MSG: mobileServerUrl('mobilepackageinfos/get_package_build_param_and_git_info/'),
    GET_COMMENTS_LOCK: mobileServerUrl('mobilepackagecomments/get_package_comments_and_islock/'),
    GET_GENERAL_TEST_INFO: mobileServerUrl('mobilepackagecheckresults/get_general_test_info/'),
    ADD_COMMENTS: mobileServerUrl('mobilepackagecomments/'),
    GET_INDEX_INFO: mobileServerUrl('mobilepackageinfos/get_index_info/'),
    GET_APP_LIST: mobileServerUrl('mobilepackageinfos/get_app_list/'),
    GET_PACKAGE: mobileServerUrl('api/get_package'),
    GET_HEADERS: mockUrl('/mobile/headers')
  },
  BUILD: {
    GET_BUILD_INFO_DATA: mobileServerUrl('mobilebuildinfos/'),
    GET_BUILD_INFO: mobileServerUrl('mobilebuildjenkinsrelations/get_job_parameters/'),
    POST_BUILD: mobileServerUrl('mobilebuildinfos/post_build/'),
    STOP_BUILD: mobileServerUrl('mobilebuildinfos/stop_build/'),
    GET_BUILD_INFO_BY_ID: mobileServerUrl('mobilepackageinfos/get_package_build_parameter_by_build_info_id/'),
    GET_DIFFS: mobileServerUrl('mobilepackageinfos/get_diffs/'),
    GET_RECENT_BUILD_VERSION: mobileServerUrl('mobilebuildinfos/get_recent_build_versions/'),
    GET_DIST_APPS: mobileServerUrl('mobilebuildjenkinsrelations/get_distinct_apps/'),
    GET_DIST_BUS: mobileServerUrl('mobilebuildjenkinsrelations/get_distinct_bus/'),
    GET_DIST_PLATFORMS: mobileServerUrl('mobilebuildjenkinsrelations/get_distinct_platforms/'),
    GET_DIST_BUILD_TYPES: mobileServerUrl('mobilebuildjenkinsrelations/get_distinct_bulid_types/')
  },
  USER: {
    GET_USER_INFO: serverUrl('userctrl/')
  },
  COMMON: {
    LOGIN_IN: '/lts/build/backend/login',
    LOGIN_OUT: '/lts/build/backend/logout',
    ACCOUNT: 'http://lujs.cn/lts/mc/my/account.html'
  }
}
