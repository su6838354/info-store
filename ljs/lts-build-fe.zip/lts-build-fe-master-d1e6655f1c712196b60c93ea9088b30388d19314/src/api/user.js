/**
 * Created by test on 18-1-18.
 */

import request from '../utils/request'
import { api } from './const'

export default {
  getUserInfo (params) {
    // return new Promise((resolve, reject) => {
    //   resolve({
    //     code: 0,
    //     message: 'success',
    //     data: {}
    //   })
    // })
    return request({
      url: api.USER.GET_USER_INFO,
      method: 'get',
      params
    })
  }
}
