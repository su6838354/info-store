/**
 * Created by test on 18-1-30.
 */

import message from '../utils/message'

export default {
  install: function (Vue, options) {
    Vue.toast = Vue.prototype.$toast = message
  }
}
