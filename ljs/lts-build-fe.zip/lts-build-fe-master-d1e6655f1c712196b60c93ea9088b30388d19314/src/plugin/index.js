/**
 * Created by test on 18-1-30.
 */

import vue from 'vue'
import toast from './toast'

vue.use(toast)
