import Vue from 'vue'
import Router from 'vue-router'
import Layout from '../pages/layout/index.vue'
import IndexPage from '../pages/index-page/index.vue'
import BuildPage from '../pages/build-page/index.vue'
import DiffGitPage from '../pages/diff-git-page/index.vue'
// import Error404 from '../pages/error-page/404'
import Lu404 from '../pages/error-page/lu-404.vue'

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    // {
    //   path: '/',
    //   name: 'HelloWorld',
    //   component: HelloWorld
    // },
    // {
    //   path: '/mobile/package',
    //   name: 'mc',
    //   component: Mc
    // }
    { path: '/404', component: Lu404, hidden: true },
    {
      path: '/lts/build/view/mobile/package',
      name: 'layout',
      component: Layout,
      redirect: '/lts/build/view/mobile/package/index',
      meta: {
        title: '打包系统', icon: 'icon', noCache: true
      },
      children: [
        {
          path: 'index', component: IndexPage, name: 'index-page', meta: { title: '首页' }
        },
        {
          path: 'build', component: BuildPage, name: 'build-page', meta: { title: '打包' }
        },
        {
          path: 'diffgit', component: DiffGitPage, name: 'diff-git-page', meta: { title: 'Git Diff' }
        }
      ]
    },
    { path: '/', redirect: '/lts/build/view/mobile/package', hidden: true },
    { path: '*', redirect: '/404', hidden: true }
  ]
})
