/**
 * Created by test on 18-1-22.
 */

const getQueryValue = (key) => {
  let aPairs
  let aTmp
  let data = {}
  let queryString = `${window.location.search}`
  queryString = queryString.substr(1, queryString.length) // remove   "?"
  aPairs = queryString.split('&')
  for (let i = 0; i < aPairs.length; i++) {
    aTmp = aPairs[i].split('=')
    data[aTmp[0]] = aTmp[1]
  }
  return data[key]
}

export default {
  getQueryValue
}
