/**
 * Created by test on 18-1-12.
 */

import { Message, MessageBox } from 'element-ui'

const duration = 5 * 1000

const _message = (type, msg) => {
  Message({
    message: msg,
    dangerouslyUseHTMLString: true,
    type,
    duration
  })
}

const message = {
  error (msg) {
    _message('error', msg)
  },
  warn (msg) {
    _message('warning', msg)
  },
  success (msg) {
    _message('success', msg)
  },
  info (msg) {
    _message('info', msg)
  },
  confirm (msg) {
    return MessageBox.confirm(msg, '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }).then(() => {
      return true
    }).catch(() => {
      return false
    })
  }
}

export default message
