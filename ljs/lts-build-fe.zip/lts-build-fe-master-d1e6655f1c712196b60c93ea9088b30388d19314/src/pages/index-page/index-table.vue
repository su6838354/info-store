<template>
  <mobile-table :rawData="rawData" :loading="loading">
    <el-table-column
      prop="id"
      label="ID"
      key="id"
      min-width="60">
      <template slot-scope="scope">
        {{ scope.row.id }}
      </template>
    </el-table-column>

    <el-table-column
      prop="packageName"
      label="名字"
      key="packageName"
      min-width="200">
      <template slot-scope="scope">
        {{ scope.row.package_name }}
      </template>
    </el-table-column>

    <el-table-column
      prop="type"
      label="类型"
      key="type"
      min-width="100">
      <template slot-scope="scope">
        <el-tag :type="scope.row.package_type_enum.style" >{{scope.row.package_type_enum.name }}</el-tag>
      </template>
    </el-table-column>

    <el-table-column
      prop="during"
      label="构建时长"
      key="during"
      min-width="100">
      <template slot-scope="scope">
        {{ scope.row.during_formated }}
      </template>
    </el-table-column>

    <el-table-column
      prop="buildStatus"
      label="构建详情(点击查看)"
      key="buildStatus"
      min-width="100">
      <template slot-scope="scope">
        <build-template :package_id="scope.row.id" :build_info="scope.row.build_status_enum"></build-template>
      </template>
    </el-table-column>

    <el-table-column
      prop="size"
      label="大小"
      key="size"
      min-width="200">
      <template v-if="scope.row.size_info" slot-scope="scope" >
        <span>{{scope.row.size_info.size_formated}}</span>
        <span v-if="scope.row.size_info.change_info" class="size-down" :class="{'size-upper': scope.row.size_info.change_info.change_type==='+'}">
          {{scope.row.size_info.change_info.change_type}}
          {{scope.row.size_info.change_info.change_size_formated}}
          {{scope.row.size_info.change_info.change_percent_formated}}
        </span>
      </template>
    </el-table-column>

    <el-table-column
      prop="buildTime"
      label="创建时间"
      key="buildTime"
      min-width="200">
      <template slot-scope="scope" >
        {{scope.row.create_time}}
      </template>
    </el-table-column>

    <el-table-column
      label="基础检测(点击查看)"
      key="jobStatus"
      min-width="100">
      <template slot-scope="scope">
        <check-template v-if="scope.row.check_result" :job_status="scope.row.job_status" :check_result="scope.row.check_result" :package_id="scope.row.id" ></check-template>
      </template>
    </el-table-column>

    <el-table-column
      label="下载/二维码"
      key="downloadPic"
      min-width="180">
      <template slot-scope="scope">
       <download-template :key="scope.row.id" :iosDevice="iosDevice" :row="scope.row" ></download-template>
      </template>
    </el-table-column>

    <el-table-column
      label="操作"
      min-width="120">
      <template slot-scope="scope">
        <lock-comment-template :row="scope.row"></lock-comment-template>
      </template>
    </el-table-column>
  </mobile-table>
</template>

<script>
  import mobileTable from '../../components/mobile-table.vue'
  import buildTemplate from './build-template.vue'
  import checkTemplate from './check-template.vue'
  import lockCommentTemplate from './lock-comment-template.vue'
  import downloadTemplate from './download-template.vue'
  import { createNamespacedHelpers } from 'vuex'

  const { mapGetters, mapActions } = createNamespacedHelpers('mobilepackage')

  export default {
    name: 'IndexTable',
    data () {
      return {
        iosDevice: false
      }
    },
    created () {
//      this.getData()
    },
    computed: {
      ...mapGetters({
        rawData: 'package_list',
        loading: 'loading'
      })
    },
    methods: {
      ...mapActions({
//        getData: 'getPackageList'
      }),
      handleLockComment () {

      }
    },
    components: {
      mobileTable,
      buildTemplate,
      checkTemplate,
      lockCommentTemplate,
      downloadTemplate
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .size-down {
    color: green;
  }
  .size-upper {
    color: red;
  }


</style>
<style>
  .arrow-up{
    color: red;
  }
</style>
