<template>
  <div>
      <index-params @search="fetchData" :params="params"></index-params>


      <index-table></index-table>

  </div>
</template>

<script>
  import indexParams from './index-params.vue'
  import indexTable from './index-table.vue'
  import { createNamespacedHelpers } from 'vuex'
  const { mapGetters, mapActions } = createNamespacedHelpers('mobilepackage')
  export default {
    name: 'IndexPage',
    data () {
      return {
      }
    },
    computed: {
      ...mapGetters({
        params: 'params'
      })
    },
    created () {
      this.fetchData()
      // 获取APP
      this.$watch(vm => [vm.params.begin_date, vm.params.end_date].join(), val => {
        this.updateAppList()
      })
      // 获取version list
      this.$watch(vm => [vm.params.app, vm.params.platform, vm.params.begin_date, vm.params.end_date].join(), val => {
        this.updateVersionList()
      })
      // 获取build type list
      this.$watch(vm => [vm.params.app, vm.params.platform, vm.params.version, vm.params.begin_date, vm.params.end_date].join(), val => {
        this.updateBuildTypeList()
      })
    },
    methods: {
      ...mapActions({
        fetchData: 'fetchPackageList',
        updateAppList: 'updateAppList',
        updateVersionList: 'updateVersionList',
        updateBuildTypeList: 'updateBuildTypeList'
      })
    },
    watch: {

    },
    components: {
      indexParams,
      indexTable
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
