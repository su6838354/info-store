<template>
  <div>
    <el-popover
      ref="popover_build"
      placement="right"
      title="构建详情"
      min-width="200"
      trigger="click"
      @show="refresh"
    >
      <build-info ref="build-info" :packageId="package_id"></build-info>
    </el-popover>
    <div v-popover:popover_build class="fe-pointer">
      <el-tag :type="build_info.style==='info'?'success':'danger'" >
        {{ build_info.desc }}
      </el-tag>
      <i class="el-icon-info" ></i>
    </div>
  </div>

</template>

<script>
  import buildInfo from './build-info.vue'
  export default {
    name: 'BuildTemplate',
    props: ['build_info', 'package_id'],
    data () {
      return {
      }
    },
    methods: {
      refresh () {
        this.$refs['build-info'].fetchData()
      }
    },
    components: {
      buildInfo
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
