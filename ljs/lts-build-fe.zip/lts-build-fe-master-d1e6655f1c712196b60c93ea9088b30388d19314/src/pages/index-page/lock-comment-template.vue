<template>
  <span>
    <el-popover
      ref="popover_lock"
      placement="left"
      title="添加备注"
      min-width="200"
      trigger="click"
      @show="refresh"
    >
      <comment ref="commentRef" :packageId="row.id"></comment>
    </el-popover>

    <el-tooltip :content="lock_status?'已锁定':'未锁定'">
      <el-switch :value="lock_status"
                 @change="setPackageLocked"></el-switch>
    </el-tooltip>

    <el-button
      v-popover:popover_lock
      size="mini"
      type="primary">
      备注
    </el-button>
  </span>
</template>

<script>
  import comment from './comment.vue'
  import { createNamespacedHelpers } from 'vuex'
  const { mapActions } = createNamespacedHelpers('mobilepackage')
  export default {
    name: 'LockCommentTemplate',
    props: ['row'],
    data () {
      return {
      }
    },
    created () {
    },
    beforeUpdate () {

    },
    computed: {
      packageId () {
        return this.row.id
      },
      lock_status () {
        return !!this.row.lock_status
      }
    },
    methods: {
      setPackageLocked (value) {
        this.$store.dispatch({
          type: 'mobilepackage/setPackageLocked',
          package_id: this.packageId,
          lock_status: value ? 1 : 0
        })
      },
      ...mapActions({
      }),
      refresh () {
        this.$refs['commentRef'].fetchData()
      }
    },
    components: {
      comment
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
