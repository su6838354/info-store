<template>
  <div style="max-height:40rem; overflow: auto">
    <label>Branch</label>
    <hr>
    <el-table
      :data="getBranchList"
      size="mini"
      stripe
      :show-header="false"
      v-loading="loading"
      style="width: 100%">
      <el-table-column
        prop="name"
        label="分支"
        width="180">
      </el-table-column>
      <el-table-column
        label="tag"
        width="180">
        <template slot-scope="scope">
          {{ scope.row.value }}
        </template>
      </el-table-column>

    </el-table>

    <div style="margin-top: 1rem">
      <label >GitInfo</label>
      <hr/>
      <el-table
        :data="build_info.changeSet"
        size="mini"
        stripe
        v-loading="loading"
        :show-header="false"
        style="width: 100%">
        <el-table-column
          prop="date"
          label="日期"
          width="180">
        </el-table-column>
        <el-table-column
          prop="author"
          label="author"
          width="180">
        </el-table-column>
        <el-table-column
          label="msg"
          width="360">
          <template slot-scope="scope">
            <a target="_blank" :href="`${scope.row.revision.gitlabDomain}${scope.row.revision.projectPath}/${scope.row.revision.projectName}/commits/${scope.row.commitId}`">
              {{ scope.row.msg }}
            </a>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div v-if="build_info.changeSet.length!=0" style="margin-top: 1rem; margin-bottom: 1rem">
      <el-input style="width: 8rem" v-model="targetId" placeholder="请输入比较的ID"></el-input>
      <el-button-group>
        <el-button type="primary" @click="diffId" >比较ChangeSet</el-button>
        <el-button type="success" @click="diffToday">比较当天的ChangeSet</el-button>
      </el-button-group>
    </div>
  </div>
</template>

<script>
  import mcApi from '../../api/mc-api'
  export default {
    name: 'BuildInfo',
    props: ['packageId'],
    data () {
      return {
        build_info: {
          parameters: [],
          changeSet: []
        },
        loading: false,
        targetId: ''
      }
    },
    created () {
//      this.fetchData()
    },
    computed: {
      getBranchList () {
        return this.build_info.parameters.filter(item => {
          return item.value
        })
      }
    },
    methods: {
      diffToday () {
        const url = `diffgit?day=current&sourceId=${this.packageId}`
        window.open(url)
//        this.$router.push(url)
      },
      diffId () {
        const id = this.targetId
        if (!id) {
          return this.$toast.warn('请输入正确的id')
        }
        const url = `diffgit?targetId=${id}&sourceId=${this.packageId}`
        window.open(url)
//        this.$router.push(url)
      },
      fetchData () {
        this.loading = true
        mcApi.getBuildMsg({ package_id: this.packageId }).then(response => {
          this.build_info = response.data
          this.loading = false
        })
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
