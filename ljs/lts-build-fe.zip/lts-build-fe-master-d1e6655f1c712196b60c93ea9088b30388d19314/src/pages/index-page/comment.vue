<template>
    <div >
      <hr/>
      <el-table
        :data="lock_comment_info.comments"
        size="mini"
        stripe
        style="width: 100%">
        <el-table-column
          prop="create_time"
          label="时间"
          width="180">
        </el-table-column>
        <el-table-column
          prop="user_id"
          label="用户"
          width="180">
        </el-table-column>
        <el-table-column
          label="内容"
          width="180">
          <template slot-scope="scope">
            {{ scope.row.comments }}
          </template>
        </el-table-column>
        <el-table-column
          label="操作"
          min-width="120">
          <template slot-scope="scope">
            <el-button
              @click="deleteComment(scope.row.id)"
              size="mini"
              type="danger">
              删除
            </el-button>
          </template>
        </el-table-column>

      </el-table>
      <el-form size="mini" label-suffix=":">
        <el-form-item label="评论">
          <el-input type="textarea" v-model="content"></el-input>
        </el-form-item>
        <el-form-item >
          <el-button type="primary" @click="onSubmit">提交</el-button>

        </el-form-item>
      </el-form>

    </div>
  </div>
</template>

<script>
  import mcApi from '../../api/mc-api'
  export default {
    name: 'LockComment',
    props: ['packageId'],
    data () {
      return {
        lock_comment_info: {
          comments: [
          ]
        },
        content: ''
      }
    },
    created () {
//      this.fetchData()
    },
    computed: {
    },
    methods: {
      fetchData () {
        mcApi.getPackageCommentsLock({ package_id: this.packageId }).then(({data, code}) => {
          if (code === 0) {
            this.lock_comment_info.comments = data.comments
          }
        })
      },
      onSubmit () {
        mcApi.addComments({
          package_id: this.packageId,
          user_id: 111,
          comments: this.content
        }).then(response => {
          if (response.code === 0) {
            this.lock_comment_info.comments.push(response.data)
          }
          console.log(response)
        })
      },
      deleteComment (commentId) {
        mcApi.deleteComments(commentId).then(({code}) => {
          if (code === 0) {
            this.lock_comment_info.comments = this.lock_comment_info.comments.filter(item => {
              return item.id !== commentId
            })
          }
        })
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
