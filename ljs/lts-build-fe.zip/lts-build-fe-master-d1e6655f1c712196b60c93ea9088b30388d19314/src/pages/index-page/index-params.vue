<template>
  <el-form :inline="true" ref="form"
           :model="params"
           label-width="80px"  label-suffix=":">
    <el-form-item label="APP">
      <el-radio-group v-model="params.app" >
        <el-radio v-for="item in params.app_list" border :label="item" :key="item"></el-radio>
      </el-radio-group>
    </el-form-item>

    <el-form-item label="平台">
      <el-radio-group v-model="params.platform" >
        <el-radio v-for="item in params.platform_list" border :label="item" :key="item"></el-radio>
      </el-radio-group>
    </el-form-item>

    <el-form-item label="版本">
      <el-select clearable v-model="params.version" filterable placeholder="请选择">
        <el-option
        v-for="item in versionList"
        :key="item"
        :label="item"
        :value="item">
        </el-option>
      </el-select>

      <!--<el-radio-group v-model="params.version" >-->
        <!--<el-radio v-for="item in params.version_list" border :label="item" :key="item"></el-radio>-->
      <!--</el-radio-group>-->
    </el-form-item>

    <el-form-item label="类型">
      <el-select v-model="params.build_type" filterable placeholder="请选择">
        <el-option
          v-for="item in params.type_list"
          :key="item"
          :label="item"
          :value="item">
        </el-option>
      </el-select>

      <!--<el-radio-group v-model="params.type" >-->
        <!--<el-radio v-for="item in params.type_list" border :label="item" :key="item"></el-radio>-->
      <!--</el-radio-group>-->
    </el-form-item>

    <el-form-item label="种类">
      <el-select v-model="params.display" placeholder="请选择">
        <el-option
          v-for="item in params.display_list"
          :key="item.value"
          :label="item.name"
          :value="item.value">
        </el-option>
      </el-select>

      <!--<el-radio-group v-model="params.display" >-->
        <!--<el-radio v-for="item in params.display_list" border :label="item" :key="item"></el-radio>-->
      <!--</el-radio-group>-->
    </el-form-item>

    <el-form-item label="时间筛选">
      <el-col :span="10">
        <el-date-picker type="date" placeholder="选择开始日期" v-model="params.begin_date" value-format="yyyy-MM-dd" style="width: 100%;"></el-date-picker>
      </el-col>
      <el-col class="line mobile-center" :span="1">-</el-col>
      <el-col :span="10">
        <el-date-picker type="date" placeholder="选择截止日期" v-model="params.end_date" value-format="yyyy-MM-dd" style="width: 100%;"></el-date-picker>
      </el-col>
    </el-form-item>

    <el-form-item >
      <el-button type="primary" @click="onSubmit">立即查询</el-button>
      <a target="_blank" href="http://lujs.cn/confluence/pages/viewpage.action?pageId=285639243">
        <i class="el-icon-question"></i>
      </a>
    </el-form-item>

    <el-form-item >
      <el-button type="success" @click="onBuild">我要打包</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
  export default {
    name: 'indexParams',
    data () {
      return {
      }
    },
    props: ['params'],
    computed: {
      versionList () {
        return this.params.version_list.reverse()
      }
    },
    methods: {
      onSubmit () {
        this.$emit('search')
      },
      onBuild () {
        this.$router.push({name: 'build-page'})
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .mobile-center{
    text-align: center;
  }

</style>
