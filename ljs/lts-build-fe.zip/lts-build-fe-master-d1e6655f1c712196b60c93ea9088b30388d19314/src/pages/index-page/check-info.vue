<template>
  <div style="max-height:40rem; overflow: auto">
    <hr/>
    <el-table
      :data="check_info.info"
      size="mini"
      stripe
      :show-header="true"
      v-loading="loading"
      style="width: 100%">
      <el-table-column
        prop="name"
        label="名称"
        width="180">
      </el-table-column>
      <el-table-column
        label="状态"
        width="180">
        <template slot-scope="scope">
          <el-tag :type="scope.row.status=='成功'?'success':'danger'" >{{ scope.row.status }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column
        label="预期值"
        width="180">
        <template slot-scope="scope">
          <span v-html="scope.row.expected"></span>
        </template>
      </el-table-column>
      <el-table-column
        label="实际值"
        width="180">
        <template slot-scope="scope">
          <span v-html="scope.row.actual"></span>
        </template>
      </el-table-column>

    </el-table>
  </div>
</template>

<script>
  import mcApi from '../../api/mc-api'
  export default {
    name: 'CheckInfo',
    props: ['packageId'],
    data () {
      return {
        check_info: {
          parameters: []
        },
        loading: false
      }
    },
    created () {
    },
    computed: {

    },
    methods: {
      fetchData () {
        this.loading = true
        mcApi.getGeneralTest({ package_id: this.packageId }).then(({data, code}) => {
          this.check_info = data
        }).finally(() => {
          this.loading = false
        })
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
