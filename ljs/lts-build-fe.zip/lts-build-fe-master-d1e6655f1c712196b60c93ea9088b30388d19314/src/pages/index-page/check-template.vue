<template>
  <div>
    <el-popover
      ref="popover_check"
      placement="left"
      title="基础检查详情"
      min-width="200"
      trigger="click"
      @show="refresh"
    >

      <check-info ref="check-info" :packageId="package_id"></check-info>
    </el-popover>
    <div v-popover:popover_check class="fe-pointer">
      <span v-if="job_status<1">--</span>
      <el-tag :type="getBuildStatusStyle(check_result.general_test_status)">
        <span v-if="check_result.general_test_status==2" >通过</span>
        <span v-if="check_result.general_test_status==1" >运行中</span>
        <span v-if="check_result.general_test_status==0" >未运行</span>
        <span v-if="check_result.general_test_status==-1" >失败</span>
      </el-tag>
      <i class="el-icon-info" ></i>
    </div>
  </div>
</template>

<script>
  import checkInfo from './check-info.vue'
  export default {
    name: 'CheckTemplate',
    props: ['check_result', 'package_id', 'job_status'],
    data () {
      return {
      }
    },
    methods: {
      refresh () {
        this.$refs['check-info'].fetchData()
      },
      getBuildStatusStyle (status) {
        switch (status) {
          case -1:
            return 'danger'
          case 0:
            return 'info'
          case 1:
            return 'warning'
          case 2:
            return 'success'
        }
      }
    },
    components: {
      checkInfo
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
