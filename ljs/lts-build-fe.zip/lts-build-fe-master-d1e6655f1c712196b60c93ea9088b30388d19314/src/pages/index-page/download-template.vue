<template>
  <div>
    <el-popover
      ref="popover_qrcode"
      placement="left"
      trigger="hover"
      transition="bounce"
    >
      <qr-code :value="row.download_url" :options="{size:200}"></qr-code>
    </el-popover>
    <span v-if="!row.package_exists">--</span>

    <span v-else >
      <a v-popover:popover_qrcode :href="row.download_url" target="_blank" >点击下载</a>
    </span>
    <span>/</span>

    <!-- pu gong yin -->
    <el-popover
      v-if="row.pgy_upload_status==1"
      ref="popover_qrcode_pgy"
      placement="left"
      trigger="hover"
      transition="bounce"
    >
      <qr-code :value="row.pgy_download_url" :options="{size:200}"></qr-code>
    </el-popover>
    <span v-if="row.pgy_upload_status==1" >
      <a v-popover:popover_qrcode_pgy :href="row.pgy_download_url" target="_blank" >从蒲公英获取</a>
    </span>

    <span v-if="row.pgy_upload_status==1">/</span>

    <a target="_blank" :href="row.jenkins_url">查看Jenkins</a>
  </div>
</template>

<script>
  import qrCode from '@xkeshi/vue-qrcode'
//  import { api } from '../../api/const'

  export default {
    name: 'downloadTemplate',
    props: ['row', 'iosDevice'],
    data () {
      return {
      }
    },
    methods: {
      downLoadUrl (row) {
        return row.download_url // `${api.MC.GET_PACKAGE}?package_id=${row.id}`

//        if (row.platform === 'ios') {
//          if (this.iosDevice) {
//            return `itms-services://?action=download-manifest&url=https://wwwtestm3.lu.com/ipa/package/getplist/${row.id}/luinstall.plist`
//          }
//          return `http://172.19.80.11/mobile/package/download?packageid=${row.id}`
//        } else {
//          return `http://172.19.80.11/mobile/package/download?packageid=${row.id}`
//        }
      }
    },
    components: {
      qrCode
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
