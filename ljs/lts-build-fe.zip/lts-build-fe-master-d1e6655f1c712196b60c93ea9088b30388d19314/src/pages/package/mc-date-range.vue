<template>
  <div class="input-group" style="width: 250px">
      <span class="input-group-addon filter-title">
          <label>
              时间筛选：
          </label>
      </span>
    <span class="input-group-addon filter-context">
      <input type="text" name="beginDate" ref="beginDate" :value="beginDate" data-date-format="yyyy-mm-dd"/>
      <span>~~</span>
      <input type="text" name="endDate" ref="endDate" :value="endDate" data-date-format="yyyy-mm-dd"/>
      </span>
  </div>
</template>

<script>
export default {
  data () {
    return {
    }
  },
  props: ['beginDate', 'endDate'],
  mounted () {
    (() => {
      window.$(this.$refs['beginDate']).datetimepicker({
        minView: 'month',
        autoclose: true,
        format: 'yyyy-mm-dd',
        language: 'zh-CN'
      }).on('changeDate', (ev) => {
        this.$emit('update:beginDate', ev.target.value)
      })

      window.$(this.$refs['endDate']).datetimepicker({
        minView: 'month',
        autoclose: true,
        format: 'yyyy-mm-dd',
        language: 'zh-CN'
      }).on('changeDate', (ev) => {
        this.$emit('update:endDate', ev.target.value)
      })
    })()
  },
  methods: {
    changeBeginDate ($event) {
      console.log($event)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
input{
  width: 100px
}
</style>
