/**
 * Created by liuyinping on 16/12/14.
 */





const getbuildtypelistUrl = url('/package/getbuildtypelist')
const getbuildlistUrl = url('/package/getbuildlist')



const setPackageLockedUrl = url('/package/setpackagelocked')
const savePackageCommentUrl = url('/package/addcomment')
const deletePackageCommentUrl = url('/package/deletecomment')
const setPackageLockedErrorMsg = '锁定包失败，请刷新页面后重试'
const setPackageCommentErrorMsg = '添加comment失败，请刷新页面后重试'
const deleteCommentConfirm = '是否要删除？'
const deleteCommentErrorMsg = '删除失败，请刷新页面后重试'

$(function(){


    // //点击显示上传构建类型
    // $("#dropdown_chooseType").on("click","a",function(){
    //     return chooseBt(this);
    // });
    //
    //
    //
    //
    //
    // $("#example a[tag='copyLink']")
    //     .popover({
    //         html: true,
    //         content: function () {
    //             return $("#templdate_popover_copyurl").html();
    //         },
    //         trigger: "manual",
    //         placement: 'left'
    //     })
    //     .on("click", function (event) {
    //         return displayCopyUrl(this,event);
    //     });

    //弹出git diff层
    $(document)
        .on("click","#btn_diffBranch",showDiffDiv)
        .on("click","#btn_diff_by_id", diffById)
        .on("click","#btn_diff_by_today", diffByToday)
        .on("click","#btn_diff_by_current", diffByCurrent)
        .on("click","#cbx_lock", lockPackage)
        .on("click","#btn_submitComment", saveComment)
        .on("click","#dialog_comment i[tag='i_remove_comment']", deleteComment)
        .on("focus","#txt_copyUrl",function () {
            $(this).select();
        });





    //隐藏基础检查结果
    $("#div_body")
        .on("click", "#btn_closePopover_info", function () {
            $("div.popover").popover("hide");
        });

    // //点击APP
    // $("#div_app")
    //     .on("click","input[name='app']",function(){
    //         setBu();
    //     });

    //点击BU
    $("#div_bu")
        .on("click","input[name='bu']",function(){
            setVersion();
        });

    //点击平台
    $("#div_platform")
        .on("click","input[name='platform']",function(){
//              alert(this.value);
//              $("#div_body").find("input[type='radio']:checked")
//              $("#div_body").find("input[name='platform']:checked").val()
            var div_body = $("#div_body");
            if (this.value=="ios"){
                div_body.find("input[value='adhoc']").prop("checked","checked");
            }else {
                div_body.find("input[value='release']").prop("checked","checked");
            }
            setVersion();
        });

    //点击版本
    $("#div_version")
        .on("click","input[name='version']",function(){
            setBuildType();
        });

    //不显示job了
    // //点击筛选类型
    // $("#div_type")
    //     .on("click","input[name='type']",function(){
    //         setBuild();
    //     });


    //上传包
    $('#uploadBtn').click(showModalDialog);
    $("#btnSubmit").click(submitform);





});
function setBu() {
    var div_body = $("#div_body");

    var app = div_body.find("input[name='app']:checked").val();
    var beginDate = $("#txt_beginDate").val();
    var endDate = $("#txt_endDate").val();

    var url = getbulistUrl+"?app="+app+"&beginDate="+beginDate+"&endDate="+endDate;
    $.ajax({
        url: url,
        type: "get",
        dataType: "json",
        error: function () {},
        success: function (res) {
            var jsonObj = res;
            var bus = jsonObj.data[0];

            var html = "<span class='input-group-addon filter-title'> <label> BU：</label></span>";
            var checked ="";

            if(bus.length ==1){
                checked = "checked='checked'"
            }
            for(var bu in bus){
                var ver = bus[bu];
                if(ver == "主APP"){
                    checked = "checked='checked'"
                }
                html = html+ "<span class='input-group-addon filter-context'> <label> <input name='bu'  value="+ver+" type='radio' "+checked+" > "+ver+" </label> </span>";
                checked = "";
            }

            var div_bu = $("#div_bu");
            div_bu.empty();
            div_bu.append(html);

            setVersion();



            // var sub = $("#btn_filterDate");
            // if(builds.length >1) {
            // sub.removeAttr("disabled");
            // }
            //禁用提交
            // sub.prop("disabled", "true");
        }
    });
}



function setBuildType() {

    var div_body = $("#div_body");

    var app = div_body.find("input[name='app']:checked").val();
    var bu = div_body.find("input[name='bu']:checked").val();
    var platform = div_body.find("input[name='platform']:checked").val();
    var version = div_body.find("input[name='version']:checked").val();
    var beginDate = $("#txt_beginDate").val();
    var endDate = $("#txt_endDate").val();

    var url = getbuildtypelistUrl+"?app="+app+"&bu="+bu+"&platform="+platform+"&version="+version+"&beginDate="+beginDate+"&endDate="+endDate;
    $.ajax({
        url: url,
        type: "get",
        dataType: "json",
        error: function () {},
        success: function (res) {
            var jsonObj = res;
            var types = jsonObj.data[0];

            var html = "<span class='input-group-addon filter-title'> <label> 类型：</label></span>";
            // if(versions.length==0){
            //     html = html + "<span class='input-group-addon filter-context'> <label>该时间段内无数据，请重新筛选 </label> </span>";
            // }else {
            var checked ="";

            if(types.length ==1){
                checked = "checked='checked'"
            }
            for (var tt in types) {
                var ver = types[tt];
                if (platform == "ios" && ver =="adhoc") {
                    checked = "checked='checked'"
                }else if(platform == "android" && ver =="release"){
                    checked = "checked='checked'"
                }
                html = html + "<span class='input-group-addon filter-context'> <label> <input name='type'  value=" + ver + " type='radio' " + checked + " > " + ver + " </label> </span>";
                checked = "";
            }
            // }
            var div_type = $("#div_type");
            div_type.empty();
            div_type.append(html);


            //清空build，点击版本再显示
            var div_build = $("#div_build");
            div_build.empty();
            //不显示job信息了，只是把div隐藏了，所以清空div_build，但注释掉setBuild（）
            // setBuild();//不显示job

            // if(versions.length ==1){
            //     div_body.find("input[name='version']").prop("checked","checked");

            // var sub = $("#btn_filterDate");
            // // if(builds.length >1) {
            // sub.removeAttr("disabled");
            // // }
        }
    });
}

function setBuild() {
    var div_body = $("#div_body");

    var app = div_body.find("input[name='app']:checked").val();
    var bu = div_body.find("input[name='bu']:checked").val();
    var platform = div_body.find("input[name='platform']:checked").val();
    var version = div_body.find("input[name='version']:checked").val();
    var type = div_body.find("input[name='type']:checked").val();

    var beginDate = $("#txt_beginDate").val();
    var endDate = $("#txt_endDate").val();

    var url = getbuildlistUrl+"?app="+app+"&bu="+bu+"&platform="+platform+"&version="+version+"&type="+type+"&beginDate="+beginDate+"&endDate="+endDate;
    $.ajax({
        url: url,
        type: "get",
        dataType: "json",
        error: function () {},
        success: function (res) {
            var jsonObj = res;
            var builds = jsonObj.data[0];

                var html = "<span class='input-group-addon filter-title'> <label> Job：</label></span>";
            // if(versions.length==0){
            //     html = html + "<span class='input-group-addon filter-context'> <label>该时间段内无数据，请重新筛选 </label> </span>";
            // }else {
                for (var build in builds) {
                    var ver = builds[build];
                    var checked = "";
                    if (ver == "all") {
                        checked = "checked='checked'"
                    }
                    html = html + "<span class='input-group-addon filter-context'> <label> <input name='build'  value=" + ver + " type='radio' " + checked + " > " + ver + " </label> </span>";
                }
            // }
            var div_build = $("#div_build");
            div_build.empty();
            div_build.append(html);

            var sub = $("#btn_filterDate");
            // if(builds.length >1) {
            sub.removeAttr("disabled");
            // }
        }
    });
}





//上传，选择构建类型
function chooseBt(obj){
    var bt = $(obj).attr("bt");
    var btText = $(obj).text();

    $("#btn_build_type span:eq(0)").text(btText);
    $("#btn_build_type span:eq(0)").attr("bt",bt);
    $("#build_type").val(bt);
}









function showModalDialog() {
    $('#myModal').modal('show');
}

function submitform(){
    $("#frm_upload").submit();
}


function showDiffDiv(){
    var $diffDiv = $("#div_git_diff");
    //var btn = $(btn);
    $diffDiv.toggle();
}

function diffById(){
    var sourceId = $("#hid_package_id").val();
    var $link = $(this).parent();
    var targetId = $link.siblings("input").val();
    if($.trim(targetId)!=""){
        $link.attr("href", $link.attr("href")+"?sourceId="+sourceId+"&targetId="+targetId);
    }
}

function diffByToday(){
    var sourceId = $("#hid_package_id").val();
    var link = $(this).parent();
    link.attr("href", link.attr("href")+"&sourceId="+sourceId)
}

function diffByCurrent(){
    var sourceId = $("#hid_package_id").val();
    var link = $(this).parent();
    link.attr("href", link.attr("href")+"&sourceId="+sourceId)
}

function lockPackage(){
    var pid = $(this).attr("pid");
    var locked;
    if($(this).prop("checked")){
        locked = true;
    }
    else{
        locked = false;
    }
    var data = {packageid:pid,locked:locked};
    $.ajax({
        url:setPackageLockedUrl,
        data:data,
        type:"post",
        dataType:"json",
        error:function () {
            alert(setPackageLockedErrorMsg);
        },
        success:function (res) {
            if(res.status){
                // $(this).prop("checked", res.data.locked);
            }
            else if(res.message){
                alert(res.message);
            }
            else{
                alert(setPackageLockedErrorMsg);
            }
        }
    });
}


function  saveComment() {
    var comment = $("#txt_packageComment").val();
    var packageid = $("#cbx_lock").attr("pid");
    if($.trim(comment)==""){
        alert("comment不能为空");
        return false;
    }
    var data = {
        packageid:packageid,
        comment:comment
    };

    $.ajax({
        url : savePackageCommentUrl,
        type:"post",
        data:data,
        dataType:"json",
        error:function () {
            alert(setPackageCommentErrorMsg);
        },
        success:function (res) {
            if(res.status){
                generaCommentTr(res);
                $("#txt_packageComment").val("");
            }
            else if(res.message){
                alert(res.message);
            }
            else{
                alert(setPackageCommentErrorMsg);
            }
        }

    });
}

function deleteComment(){
    var pcid = $(this).attr("pcid");
    var packageid = $("#cbx_lock").attr("pid");
    if(window.confirm(deleteCommentConfirm)){
        var data = {id:pcid,packageid:packageid};
        $.ajax({
            url:deletePackageCommentUrl,
            data:data,
            type:"post",
            dataType:"json",
            error:function () {
                alert(deleteCommentErrorMsg);
            },
            success:function (res) {
                if(res.status){
                    generaCommentTr(res);
                }
                else if(res.message){
                    alert(res.message);
                }
                else{
                    alert(deleteCommentErrorMsg)
                }
            }

        });
    }
}

function displayCopyUrl(obj,event) {
    var url = $(obj).attr("url");
    $(obj).popover("show");
    $("#txt_copyUrl").val(url);
    event.preventDefault();

}
