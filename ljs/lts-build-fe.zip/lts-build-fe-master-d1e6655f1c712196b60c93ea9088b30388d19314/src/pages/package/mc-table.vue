<template>
  <div>
  <table id="example" class="display" cellspacing="0" width="100%">
    <thead>
    <tr>
      <th>ID</th>
      <th>名字</th>
      <th>类型</th>
      <th>构建时长</th>
      <th>构建详情<br/>(点击查看)</th>
      <th>大小</th>
      <th>创建时间</th>
      <th>基础检测<br/>(点击查看)</th>
      <th>下载/二维码</th>
      <th class="table-op">操作</th>
    </tr>
    </thead>
    <tbody>
    <tr v-for="pk in data.packageList">
      <td name="id">{{pk.id}}</td>
      <td>{{pk.packageName}}</td>
      <td><span class="label" :class="`label-${data.typeStyleMap[pk.id]}`">{{data.typeNameMap[pk.id]}}</span></td>
      <td>{{data.duringMap[pk.id]}}</td>
      <td>
        <span name="span_getMore" class="label pointer" :class="`label-${data.buildStatusEnumerMap[pk.id].style}`">{{data.buildStatusEnumerMap[pk.id].desc}}</span>
      </td>
      <td><span v-html="data.sizeMap[pk.id]"></span></td>
      <td>{{data.dataMap[pk.id]}}</td>
      <td>
        <span v-if="pk.jobStatus<1">--</span>

        <span v-if="pk.checkResult.generalTestStatus==2" name="span_getInfo" class="label label-success pointer">通过</span>
        <span v-if="pk.checkResult.generalTestStatus==1" class="label label-info">运行中</span>
        <span v-if="pk.checkResult.generalTestStatus==0" class="label label-default">未运行</span>
        <span v-if="pk.checkResult.generalTestStatus==-1" name="span_getInfo" class="label label-danger pointer">失败</span>
      </td>
      <td>
        <span v-if="!pk.packageExists">--</span>
        <span v-else-if="pk.platform=='ios'">
                 <a v-if="data.isIOS==true" tag="downloadPic"
                    plist="null"
                    href="itms-services://?action=download-manifest&url=https://wwwtestm3.lu.com/ipa/package/getplist/${pk.id}/luinstall.plist" target="_blank" >点击下载</a>
                 <a v-else tag="downloadPic"
                    plist="&iosFlag=true"
                    :href="`http://${jenkinsHost}${CONTEXT}/package/download?packageid=${pk.id}`" target="_blank" >点击下载</a>
              </span>
        <a v-else tag="downloadPic" :href="`http://${data.jenkinsHost}${CONTEXT}/package/download?packageid=${pk.id}`" target="_blank" >点击下载</a>
        <span>/</span>
        <a target="_blank" href="http://lujs.cn/mobile/jenkins/job/${pk.jobname}/${pk.buildId}">查看Jenkins</a>
      </td>
      <td>
        <i class="glyphicon glyphicon-lock pointer" :class="lockedOpacity(pk)" name="i_tag" :pid="pk.id" title="添加锁-备注"></i>
        <i class="glyphicon glyphicon-comment pointer$" :class="commentOpacity(pk)" name="i_tag" :pid="pk.id" title="添加锁-备注"></i>
      </td>
    </tr>
    </tbody>
  </table>
    <mc-build-detail></mc-build-detail>
    <mc-general-detail></mc-general-detail>
    <mc-comment></mc-comment>
  </div>
</template>

<script>
  import { url } from '../../api/const'
  import mcBuildDetail from './mc-build-detail.vue'
  import mcGeneralDetail from './mc-general-detail.vue'
  import mcComment from './mc-comment.vue'
  export default {
    props: ['data'],
    data () {
      return {
        CONTEXT: '/mobile/'
      }
    },
    mounted () {
      const $ = window.$
      $('#example').DataTable({
        // 排序
        'order': [ [0, 'desc'] ]
      })
      // 二维码鼠标移入显示
      const vm = this
      $('#example tbody').on('mouseover', 'a[tag="downloadPic"]', function () {
        vm.displayPic(this)
      })
      // 二维码鼠标移出隐藏
      $('#example tbody').on('mouseout', 'a[tag="downloadPic"]', function () {
        vm.hidePic(this)
      })
      // 显示构建详情
      window.setTimeout(() => {
        $('span[name="span_getMore"]')
          .popover({
            html: true,
            content: function () {
              return $('#templdate_popover_head').html()
            },
            trigger: 'manual',
            placement: 'right'
          })
          .on('click', function (event) {
            // var _this = this;
            if ($(this).siblings('div.popover').length === 0) {
              $('div.popover').popover('hide')
              vm.setPopoverValue(this)
              event.stopPropagation()
            }
          })
        // 隐藏构建详情
        $('#div_body')
          .on('click', '[close-tag="btn_closePopover"]', function () {
            $('div.popover').popover('hide')
          })
        // 显示基础检查结果
        $('span[name="span_getInfo"]')
          .popover({
            html: true,
            content: function () {
              return $('#templdate_popover_head_info').html()
            },
            trigger: 'manual',
            placement: 'right'
          })
          .on('click', function (event) {
            if ($(this).siblings('div.popover').length === 0) {
              $('div.popover').popover('hide')
              vm.setPopoverValueInfo(this)
              event.stopPropagation()
            }
          })
        // 显示备注
        $('#example i[name="i_tag"]')
          .popover({
            html: true,
            content: function () {
              return $('#templdate_popover_comment').html()
            },
            trigger: 'manual',
            placement: 'left'
          })
          .on('click', function (event) {
            if ($(this).siblings('div.popover').length === 0) {
              $('div.popover').popover('hide')
              vm.showTagComment(this)
              event.stopPropagation()
            }
          })
      }, 200)
    },
    computed: {
      getbuildmsgUrl () {
        return url('/mobile/package/getbuildmsg')
      },
      getgeneraltestinfoUrl () {
        return url('/mobile/package/getgeneraltestinfo')
      },
      getPackageCommentUrl () {
        return url('/mobile/package/getpackagecommentsandlock')
      }
    },
    methods: {
      lockedOpacity (pk) {
        if (pk.lockStatus == null || pk.lockStatus === false) {
          return 'opacity'
        }
      },
      commentOpacity (pk) {
        if (this.data.commentMap != null && this.data.commentMap[pk.id] == null) {
          return 'opacity'
        }
      },
      // 生成二维码并显示
      displayPic (obj) {
        const $ = window.$
        let packageurl = null
        // 如果已生成，则显示；未生成，则生成并显示
        if ($(obj).parent().find('div').length === 0) {
          if ($(obj).attr('plist')) {
            // plist=null表名是ios设备访问此页面，不需要二维码
            if ($(obj).attr('plist') === 'null') {
              return false
            }
            packageurl = obj.href + $(obj).attr('plist')
          } else {
            packageurl = obj.href
          }

          const pele = obj.parentElement
          let x = $(obj).offset().left
          let y = $(obj).offset().top

          const tb = $('#example_wrapper')
          const tbx = tb.offset().left
          const tby = tb.offset().top
          const w = 140
          const h = 140

          x = x - tbx - w - 20
          y = y - tby - h / 2
          const divout = document.createElement('div')
          divout.setAttribute('id', 'packagePic')
          divout.setAttribute('style', 'left:' + x + 'px;top:' + y + 'px;')
          divout.setAttribute('class', 'picClass')

          $(pele).append(divout)
          $(divout).qrcode({width: w - 40, height: h - 40, text: packageurl})

          //    render   : 'canvas',//设置渲染方式
          //    width       : 256,     //设置宽度
          //    height      : 256,     //设置高度
          //    typeNumber  : -1,      //计算模式
          //    correctLevel    : QRErrorCorrectLevel.H,//纠错等级
          //    background      : '#ffffff',//背景颜色
          //    foreground      : '#000000' //前景颜色
        } else {
          $(obj).parent().find('div').show()
        }
      },
      // 隐藏二维码
      hidePic (obj) {
        window.$(obj).parent().find('div').hide()
      },
      // 设置构建详情显示的值，包括构建参数和Git提交说明
      setPopoverValue (obj) {
        const $ = window.$
        // 获取id
        const parentTr = $(obj).parent().parent()
        const packageid = parentTr.find('td[name=id]').text()
        const url = this.getbuildmsgUrl + '?packageid=' + packageid
        $.ajax({
          url: url,
          type: 'get',
          dataType: 'json',
          error: function () {
          },
          success: function (res) {
            const jsonObj = res
            const jsonParameters = jsonObj.parameters
            const jsonChangeSet = jsonObj.changeSet

            // 设置构建参数的值，并添加到表格中
            const tboBranch = $('tbody[name="tbo_branch"]')
            $(tboBranch).empty()
            let strBranch = ''

            for (let branch in jsonParameters) {
              const name = jsonParameters[branch].name
              const value = jsonParameters[branch].value
              if (value !== '') {
                strBranch = `${strBranch}<tr><td style='padding-top: 1px;padding-bottom: 1px;'>${name}${value}</td></tr>`
              }
            }
            tboBranch.append(strBranch)

            // 设置Git提交说明的值，并添加到表格中
            const tboGitinfo = $('tbody[name="tbo_gitinfo"]')
            // 将package id保存起来
            $('#hid_package_id').val(packageid)
            $(tboGitinfo).empty()
            let strGitinfo = ''
            let date, author, msg, revision, commitId, commitUrl
            for (let gitinfo in jsonChangeSet) {
              date = jsonChangeSet[gitinfo].date
              author = jsonChangeSet[gitinfo].author
              msg = jsonChangeSet[gitinfo].msg
//              paths = jsonChangeSet[gitinfo].paths
              commitId = jsonChangeSet[gitinfo].commitId
              revision = jsonChangeSet[gitinfo].revision
              if (msg !== '') {
                strGitinfo = `${strGitinfo}<tr><td nowarp style='padding-top: 1px;padding-bottom: 1px;'>${date}</td>`
                strGitinfo = `${strGitinfo}<td nowarp style='padding-top: 1px;padding-bottom: 1px;'>${author}</td>`
                if (revision && revision.gitlabDomain) {
                  commitUrl = revision.gitlabDomain + revision.projectPath + '/' + revision.projectName + '/commits/' + commitId
                  strGitinfo = `${strGitinfo}<td style='padding-top: 1px;padding-bottom: 1px;'><a href=${commitUrl} target='_blank'>${msg}</a></td></tr>`
                } else {
                  strGitinfo = `${strGitinfo}<td style='padding-top: 1px;padding-bottom: 1px;'>${msg}</td></tr>`
                }
              }
            }
            tboGitinfo.append(strGitinfo)
            $(obj).popover('show')
          }
        })
      },
      // 设置基础检查显示的值
      setPopoverValueInfo (obj) {
        // 获取id
        const $ = window.$
        const parentTr = $(obj).parent().parent()
        const packageid = parentTr.find('td[name=id]').text()
        const url = this.getgeneraltestinfoUrl + '?packageid=' + packageid

        // 异步获取基础检查结果接口
        $.ajax({
          url: url,
          type: 'get',
          dataType: 'json',
          error: function () {
          },
          success: function (res) {
            const jsonObj = res
            const jsonInfo = jsonObj.info
            const tboInfo = $('tbody[name="tbo_test_info"]')
            $(tboInfo).empty()
            let strInfo = ''
            if (jsonInfo != null) {
              for (let info in jsonInfo) {
                var name = jsonInfo[info].name
                var status = jsonInfo[info].status
                var expected = jsonInfo[info].expected
                var actual = jsonInfo[info].actual
//                var classStr
//                if (status === '成功') {
//                  classStr = 'arrow-down'
//                } else {
//                  classStr = 'arrow-up'
//                }
                strInfo = `${strInfo}<tr class='"+classStr+"'><td nowarp style='padding-top: 1px;padding-bottom: 1px;'>${name}检测 : ${status}</td>`
                strInfo = `${strInfo}<td nowarp style='padding-top: 1px;padding-bottom: 1px;'>${expected}</td>`
                strInfo = `${strInfo}<td style='padding-top: 1px;padding-bottom: 1px;'>${actual}</td></tr>`
              }
            }
            tboInfo.append(strInfo)
            $(obj).popover('show')
          }
        })
      },
      showTagComment (obj) {
        const $ = window.$
        const vm = this
        const packageid = $(obj).attr('pid')
        const data = {packageid: packageid}
        $.getJSON(this.getPackageCommentUrl, data, function (res) {
          if (res.status) {
            vm.generaCommentTr(res)
            $(obj).popover('show')
            var $cbx = $('#cbx_lock')
            $cbx.prop('checked', res.data.locked)
            $cbx.attr('pid', packageid)
          } else if (res.message) {
            alert(res.message)
          } else {
            alert('获取comments信息失败')
          }
        })
      },
      generaCommentTr (res) {
        const $ = window.$
        const $tbody = $('#dialog_comment table[tag="table-comment"] tbody')
        $tbody.empty()
        if (res.data.comments && res.data.comments.length > 0) {
          let $trTemplate = $('#comment_td_templdate')
          let $tr
          $(res.data.comments).each(function () {
            $tr = $trTemplate.clone()
            $tr.removeAttr('id')
            $tr.find('td[tag="time"]').text(res.data.date[this.id])
            if (res.data.user[this.userId]) {
              $tr.find('td[tag="user"]').text(res.data.user[this.userId])
            } else {
              $tr.find('td[tag="user"]').text('未知')
            }
            $tr.find('td[tag="comment"]').text(this.comments)
            $tr.find('i[tag="i_remove_comment"]').attr('pcid', this.id)
            $tr.show()
            $tbody.append($tr)
          })
        }
      }
    },
    components: {
      mcBuildDetail,
      mcGeneralDetail,
      mcComment
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
