<template>
  <div id="templdate_popover_head_info" style="display: none">
    <div id="dialog_simple_info" class="panel panel-primary" style="width:450px;">
      <div class="panel-heading">
        <h3 class="panel-title" name="title">基础检测详情</h3>
      </div>
      <div class="panel-body">
        <table class="table table-striped">
          <thead>
          <tr><th>检测结果</th><th>预期值</th><th>实际值</th></tr>
          </thead>
          <tbody name="tbo_test_info">
          </tbody>
        </table>
      </div>
      <table class="table table-striped">
        <tbody >
        <tr>
          <td colspan="3" class="center">
            <button close-tag="btn_closePopover" class="btn btn-primary">关闭</button>
          </td>
        </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
