<template>

  <div id="templdate_popover_comment" style="display: none">
    <div id="dialog_comment" class="panel panel-primary" style="width:600px;">
      <div class="panel-heading">
        <h3 class="panel-title" name="title">添加锁/备注</h3>
      </div>
      <div class="panel-body">
        <div class="div-scroll">
          <table tag="table-comment" class="table table-striped">
            <thead>
            <tr>
              <th colspan="4">锁</th>
            </tr>
            <tr>
              <th colspan="4">
                <input type="checkbox" id="cbx_lock"><label for="cbx_lock">永久保存（不保存的包后期会被清理掉）</label>
              </th>
            </tr>
            <tr><th colspan="4">Comments</th></tr>
            <tr>
              <th>时间</th>
              <th>用户</th>
              <th>内容</th>
              <th>操作</th>
            </tr>
            </thead>
            <tbody>

            </tbody>
            <tfoot>
            <tr id="comment_td_templdate" style="display: none">
              <td tag="time"></td>
              <td tag="user"></td>
              <td tag="comment"></td>
              <td>
                <i tag="i_remove_comment" class="glyphicon glyphicon-remove pointer" title="删除comment"></i>
              </td>
            </tr>
            <tr>
              <td colspan="4">
                <textarea id="txt_packageComment" style="width: 100%"></textarea>
              </td>
            </tr>
            <tr>
              <td colspan="4">
                <button class="btn btn-primary" id="btn_submitComment" type="submit">提交comment</button>
              </td>
            </tr>
            </tfoot>
          </table>

        </div>
        <button  type="button" close-tag="btn_closePopover" class="btn btn-primary">关闭</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {

  data () {
    return {

    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
