<template>
  <div class="mc-submit">
      <button type="button" class="btn btn-primary" @click="submit" >提交</button>
      <a href="http://lujs.cn/confluence/pages/viewpage.action?pageId=285639243" target="_blank">
        <img id="submit-img" src="http://lujs.cn/mobile/img/help.png" title="查看使用指南" alt="?" >
      </a>

  </div>
</template>

<script>
export default {

  data () {
    return {

    }
  },
  methods: {
    submit () {
      this.$emit('mc:submit')
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  #submit-img{
    width: 16px;
    height: 16px;
  }


</style>
