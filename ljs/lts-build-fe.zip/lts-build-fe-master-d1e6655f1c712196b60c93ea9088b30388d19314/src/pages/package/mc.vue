<template>
  <div >
    <div class="container context" id = "div_body">
      <ol class="breadcrumb">
        <li><a href="#">打包系统</a></li>
        <li>包管理</li>
      </ol>

      <div>
        <form method="get">
          <input type="hidden" name="display" :value="data.expectedPackageTypeEnumer.typeCode">
          <control-radios :data="params.appList" @change="changeApp" label="APP" name="app" :value.sync="params.app"></control-radios>
          <control-radios :data="params.buList" @change="changeBu" label="BU" name="bu" :value.sync="params.bu"></control-radios>
          <control-radios :data="params.platformList" label="平台" name="platform" :value.sync="params.platform"></control-radios>
          <control-radios :data="params.versionList" label="版本" name="version" :value.sync="params.version"></control-radios>
          <control-radios :data="params.typeList" label="类型" name="type" :value.sync="params.type"></control-radios>
          <control-radios :style="{display: 'none'}" :data="params.buildList" label="Job" name="build" :value.sync="params.build"></control-radios>
          <mc-date-range :beginDate.sync="params.beginDate" :endDate.sync="params.endDate"></mc-date-range>
          <mc-submit @mc:submit="mSearch($event)"></mc-submit>
        </form>
      </div>
      <a :href="CONTEXT+'/package/build'"><button class="btn btn-primary btn-upload" type="button">我要打包</button></a>
      <hr />
      <div class="table-header-before">
        <label class="label label-success">{{params.platform}}</label>
        <label class="label label-info">{{params.version}}</label>
        <label class="label label-primary">{{params.type}}</label>
        <div class="btn-group">
          <button class="btn btn-xs dropdown-toggle" :class="'btn-'+data.expectedPackageTypeEnumer.typeStyle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            {{data.expectedPackageTypeEnumer.displayText}}
            <span class="caret"></span>
          </button>
          <ul class="dropdown-menu">
            <li><a :href="`${getBuildUrl}display=all`">显示所有包</a></li>
            <li><a :href="`${getBuildUrl}display=normal`">只显示正式包</a></li>
            <li><a :href="`${getBuildUrl}display=special`">只显示特殊包</a></li>
            <li><a :href="`${getBuildUrl}display=regression`">只显示回归包</a></li>
          </ul>
        </div>
      </div>
      <mc-table :data="data"></mc-table>
    </div>
  </div>
</template>

<script>
  import mcHeader from '../../components/mc-header.vue'
  import mcApi from '../../api/mc-api'
  import { api, url } from '../../api/const'
  import controlRadios from '../../components/control-radios.vue'
  import mcSubmit from './mc-sumbit.vue'
  import mcDateRange from './mc-date-range.vue'
  import mcTable from './mc-table.vue'
  import axios from 'axios'
  export default {
    name: 'mc',
    data () {
      return {
        data: {
          expectedPackageTypeEnumer: {typeCode: 'none'}
        },
        params: {
          buList: [],
          app: null,
          bu: null,
          appList: []
        },
        CONTEXT: api.CONTEXT
      }
    },
    created () {
      mcApi.getPackage().then(response => {
        response.params.platformList = response.params.platformList.map(item => { return item.code })
        this.params = response.params
        this.data = response.data
      })
    },
    mounted () {

    },
    methods: {
      mSearch () {
        console.log(this.params)
      },
      changeApp () {
        const { app, beginDate, endDate } =  this.params
        const url = `${this.getbulistUrl}?app=${app}&beginDate=${beginDate}&endDate=${endDate}`
        const vm = this;
        window.$.ajax({
          url: url,
          type: 'get',
          dataType: 'json',
          error: function () {

          },
          success: function (res) {
            const jsonObj = res;
            const bus = jsonObj.data[0]
            vm.params.buList = bus

            vm.setVersion();
          }
        });
      },
      changeBu (bu) {

      },
      setVersion () {
        const { app, bu, platform, beginDate, endDate} = this.params

        var url = this.getversionlistUrl+"?app="+app+"&bu="+bu+"&platform="+platform+"&beginDate="+beginDate+"&endDate="+endDate;
        axios.get(this.getversionlistUrl, {
            params: { app, bu, platform, beginDate, endDate}
        }).then(response => {
            const data = response.data

        })
//        $.ajax({
//          url: url,
//          type: "get",
//          dataType: "json",
//          error: function () {},
//          success: function (res) {
//            var jsonObj = res;
//            var versions = jsonObj.data[0];
//
//            var html = "<span class='input-group-addon filter-title'> <label> 版本：</label></span>";
//            if(versions.length==0){
//              html = html + "<span class='input-group-addon filter-context'> <label>该时间段内无数据，请重新筛选 </label> </span>";
//            }else {
//              for (var version in versions) {
//                var ver = versions[version];
//                var checked;
//                // if(version==0){
//                //     checked = "checked='checked'"
//                // }
//                if(ver != "" && ver != null) {
//                  html = html + "<span class='input-group-addon filter-context'> <label> <input name='version'  value=" + ver + " type='radio' "+checked+"> " + ver + " </label> </span>";
//                }
//
//              }
//            }
//            var div_version = $("#div_version");
//            div_version.empty();
//            div_version.append(html);
//            $("input[name='version']")[0].checked = true;
//
//            //清空build，点击版本再显示
//            var div_type = $("#div_type");
//            div_type.empty();
//
//            // if(versions.length ==1){
//            //     div_body.find("input[name='version']").prop("checked","checked");
//            setBuildType();
//            // }else {
//            //     //禁用提交
//            //     var sub = $("#btn_filterDate");
//            //     sub.prop("disabled", "true");
//            // }
//          }
//        });
      }
    },
    computed: {
      getBuildUrl () {
        const {app, bu, platform, version, type, build, beginDate, endDate} = this.params
        return `package?app=${app}&bu=${bu}&platform=${platform}&version=${version}&type=${type}&build=${build}&beginDate=${beginDate}&endDate=${endDate}&`
      },
      getbulistUrl () {
        return url('/mobile/package/getbulist')
      },
      getversionlistUrl () {
        return url('/mobile/package/getversionlist')
      }
    },
    components: {
      mcHeader,
      controlRadios,
      mcSubmit,
      mcDateRange,
      mcTable
    }
  }
</script>

<style>
  .table-header-before{
    margin-left: 200px;
    margin-bottom: -24px;
    z-index: 99;
    position: relative;
  }

  .table-op{
    width: 25px;
  }
</style>
