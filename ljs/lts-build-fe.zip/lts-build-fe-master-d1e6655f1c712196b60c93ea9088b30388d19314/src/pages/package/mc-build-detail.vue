<template>
  <div id="templdate_popover_head" style="display: none">
    <div id="dialog_simple" class="panel panel-primary" style="width:700px;">
      <div class="panel-heading">
        <h3 class="panel-title" name="title">构建详情</h3>
      </div>
      <div class="panel-body">
        <div class="div-scroll">
          <table class="table table-striped">
            <thead>
            <tr><th>Branch</th></tr>
            </thead>
            <tbody name="tbo_branch">
            </tbody>
          </table>
          <table class="table table-striped">
            <thead>
            <tr><th colspan="3">GitInfo</th></tr>
            </thead>
            <tbody name="tbo_gitinfo">
            </tbody>
          </table>
        </div>
        <table class="table table-striped">
          <tbody >
          <tr>
            <td colspan="2" class="center">
              <button close-tag="btn_closePopover" type="button" class="btn btn-primary">关闭</button>
              <button id="btn_diffBranch" type="button" class="btn btn-info">比较ChangeSet</button>
              <input type="hidden" id="hid_package_id" value="">
              <div id="div_git_diff" class="list-group div_git_diff" style="display: none">
                <li class="list-group-item">
                  <input type="text" class="text txt_git_diff" placeholder="输入比较的id号">
                  <a :href="`${CONTEXT}/package/diffgit`" target="_blank">
                    <button class="btn btn-primary" id="btn_diff_by_id" type="button">提交</button>
                  </a>
                </li>
                <li class="list-group-item">
                  <a :href="`${CONTEXT}/package/diffgit?day=current`" target="_blank">
                    <button class="btn btn-primary" id="btn_diff_by_current" type="button">比较<u>当天</u>的ChangeSet</button>
                  </a>
                </li>
              </div>

            </td>
          </tr>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</template>

<script>
  import { api } from '../../api/const'
  export default {
    data () {
      return {
        CONTEXT: api.CONTEXT
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
