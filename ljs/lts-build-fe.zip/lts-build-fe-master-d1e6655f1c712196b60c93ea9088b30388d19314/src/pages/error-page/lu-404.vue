<template>
  <div class="errPage-container">
    <div class="header" id="promHeader">
      <div class="content clearfix">
        <a href="//www.lu.com" target="_blank"><img src="https://s1-promo.lufaxcdn.com/transfer/v1/images/_7GixqIWI5iNATTxWJJNww.png" alt="" class="logo"/></a>
        <ul class="headNav clearfix">
          <li>
            <a href="//www.lu.com" target="_blank">陆金所首页</a>
          </li>
          <li>
            <a href="//www.lu.com/help/" target="_blank">帮助中心</a>
          </li>
          <li>
            <a href="//www.lu.com/help/help_service_feedback.html" target="_blank">意见反馈</a>
          </li>
        </ul>
      </div>
    </div>
    <!--	head end	-->

    <div class="contentWrapper">
      <div class="faultTolerant notFund">
        <h4 class="title">页面不存在</h4>
        <p class="content">您收藏夹中的链接可能已过期或页面地址错误</p>
        <p class="operation">
          <span style="color: #999">{{this.count}}秒后</span>
          <a class="linkHome" href="/">
            返回首页
          </a>
        </p>
      </div>
    </div>

    <!--	foot begin	-->
    <div class="footer">
      <div class="content clearfix">
        <div class="contactbox">
          <i></i><p class="phoneNum">全国服务热线<br><span class="num">4008&nbsp;6666&nbsp;18</span> </p>
          <p class="calltime">人工服务时间 8:00 - 22:00</p>
        </div><p class="wechat"><img src="https://s1-promo.lufaxcdn.com/transfer/v1/images/zV22OvEB9rfZB2qX5Dmfpg.jpg" alt=""/> </p>
        <p class="copyright">版权所有 © 上海陆家嘴国际金融资产交易市场股份有限公司未经许可不得复制、转载或摘编，违者必究!<br>Copyright Shanghai Lujiazui International Financial Asset Exchange Co.,LTD. ALL Rights Reserved<br>沪 ICP 证 B2-20120023号&emsp;&emsp;&emsp;沪 ICP 备 12032241 号-7</p>
      </div>

    </div>
  </div>
</template>

<script>
export default {
  name: 'luPage401',
  data () {
    return {
      count: 3,
      timer: null
    }
  },
  created () {
    this.timer = window.setInterval(() => {
      this.count --
      if (this.count === 0) {
        window.clearInterval(this.timer)
        this.back()
      }
    }, 1000)
  },
  destroyed () {
    window.clearInterval(this.timer)
  },
  methods: {
    back () {
      if (this.$route.query.noGoBack) {
        this.$router.push({ name: 'index-page' })
      } else {
        this.$router.go(-1)
      }
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>

  .errPage-container {
    height: 100%;
  }

  .contentWrapper {
    height: 60%;
  }

  .faultTolerant .title {
    font-size: 35px;
    font-weight: normal;
    color: #4d4398;
    margin-bottom: 30px;
  }

  .faultTolerant {
    width: 600px;
    height: 400px;
    margin-left: 180px;
    padding: 100px 0 0 240px;
  }

  .footer {
    width: 100%;
    /*margin-top: 40px;*/
    padding: 20px 0 40px;
    font-size: 12px;
    color: #333;
    border-top: 1px solid #d9d9d9;
    background: #fff;
    height: 10%;
  }

  .footer .contactbox {
    position: relative;
    margin: 9px 18px 0 0;
    float: left;
    width: 174px;
    text-align: right;
    z-index: 1;
  }

  .footer .contactbox i {
    position: absolute;
    left: 10px;
    top: -1px;
    width: 40px;
    height: 42px;
    background: url(https://s1-promo.lufaxcdn.com/transfer/v1/img/UwKaZfAEaOZS4eORxjDqQQ.png) no-repeat 0 0;
  }

  .footer .phoneNum {
    font-size: 14px;
    color: #1d2088;
  }
  .footer .calltime {
    margin-top: 3px;
  }

  .footer .content {
    width: 920px;
    margin: 0 auto;
  }

  .footer .wechat {
    float: left;
    padding-right: 39px;
    width: 86px;
    height: 84px;
  }

  .footer .copyright {
    float: left;
    color: #666;
    line-height: 18px;
    margin-top: 15px;
    padding-left: 39px;
    text-align: left;
    border-left: 1px solid #a5a5a5;
  }

  .header {
    width: 100%;
    height: 20%;
    border-top: 3px solid #1d2088;
    background: #fff;
  }

  .header .content {
    width: 1170px;
    margin: 0 auto;
  }

  .header .headNav {
    float: right;
    margin-top: 30px;
  }

  .header .headNav li {
    float: left;
    margin-left: 40px;
    display: inline-block;
  }

  .linkHome {
    font-size: 24px;
  }

</style>
