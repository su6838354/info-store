<template>
  <div>
    <el-tabs  v-model="activeId" type="card">
      <el-tab-pane v-for="(item, index) in project_group_merged_dict" :key="item.name" :label="item.name" :name="item.name">
        <mobile-table :rawData="item.rawData" :loading="loading" >
          <el-table-column
            prop="package_id"
            label="packageId"
            key="package_id"
            min-width="60">
            <template slot-scope="scope">
              {{ scope.row.package_id }}
            </template>
          </el-table-column>

          <el-table-column
            prop="date"
            label="date"
            key="date"
            min-width="60">
            <template slot-scope="scope">
              {{ scope.row.date }}
            </template>
          </el-table-column>

          <el-table-column
            prop="author"
            label="author"
            key="author"
            min-width="60">
            <template slot-scope="scope">
              {{ scope.row.author }}
            </template>
          </el-table-column>

          <el-table-column
            prop="is_revision"
            label="is_revision"
            key="is_revision"
            min-width="60">
            <template slot-scope="scope">
              <a v-if="scope.row.is_revision" target="_blank" :href="revision_merged_map[index].commit_url">{{scope.row.msg}}</a>
            </template>
          </el-table-column>
        </mobile-table>
      </el-tab-pane>
    </el-tabs>


  </div>
</template>

<script>
  import mobileTable from '../../components/mobile-table.vue'
  import mcApi from '../../api/mc-api'
  import common from '../../utils/common'

  export default {
    name: 'DiffGitPage',
    data () {
      return {
        activeId: undefined,
        project_group_merged_dict: {},
        revision_merged_map: {}
      }
    },
    created () {
      const targetId = common.getQueryValue('targetId')
      const sourceId = common.getQueryValue('sourceId')
      const day = common.getQueryValue('day')
      this.loading = true
      mcApi.getDiffs({
        target_package_id: targetId,
        source_package_id: sourceId,
        day_mode: day
      }).then(({code, data}) => {
        if (code === 0) {
          this.loading = false
          this.revision_merged_map = data.revision_merged_map
          this.project_group_merged_dict = Object.keys(data.project_group_merged_dict).map(item => {
            return {
              name: item,
              rawData: data.project_group_merged_dict[item]
            }
          })
          if (this.project_group_merged_dict[0]) {
            this.activeId = this.project_group_merged_dict[0].name
          }
        }
      })
    },
    computed: {
//      activeId () {
//        return this._activeId || (this.project_group_merged_dict[0] ? this.project_group_merged_dict[0].name : undefined)
//      }
    },
    methods: {
    },
    components: {
      mobileTable
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
