<template>
  <div>
    <el-card header="打包操作">
      <build-params @startBuild="refreshTable" style="margin-bottom: 2rem"></build-params>
    </el-card>
    <el-card header="打包记录">
      <build-table ref="buildTable"></build-table>
    </el-card>
  </div>
</template>

<script>
  import buildTable from './build-table.vue'
  import buildParams from './build-params.vue'

  export default {
    name: 'BuildPage',
    data () {
      return {
      }
    },
    computed: {

    },
    created () {
    },
    methods: {
      refreshTable () {
        this.$refs['buildTable'].$refs['table'].fetchData()
      }
    },
    watch: {

    },
    components: {
      buildParams,
      buildTable
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
