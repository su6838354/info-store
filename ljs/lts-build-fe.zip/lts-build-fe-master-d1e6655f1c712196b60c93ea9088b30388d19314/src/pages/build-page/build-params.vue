<template>
  <div>
    <el-form :inline="true"  ref="form" :model="build_info" label-width="80px">
      <el-form-item >
        <el-select v-model="build_info.app" @change="onChangeApp" filterable placeholder="请选择app">
          <el-option
            v-for="item in build_info.appList"
            :key="item"
            :label="item"
            :value="item">
          </el-option>
        </el-select>
      </el-form-item>

      <el-form-item >
      <el-select v-model="build_info.bu" @change="onChangeBu" filterable placeholder="请选择bu">
        <el-option
          v-for="item in build_info.buList"
          :key="item"
          :label="item"
          :value="item">
        </el-option>
      </el-select>
      </el-form-item>

      <el-form-item >
      <el-select v-model="build_info.platform" @change="onChangePlatform" filterable placeholder="请选择platform">
        <el-option
          v-for="item in build_info.platformList"
          :key="item"
          :label="item"
          :value="item">
        </el-option>
      </el-select>
      </el-form-item>

      <el-form-item >
      <el-select v-model="build_info.type" @change="onChangeBuildType" filterable placeholder="请选择build type">
        <el-option
          v-for="item in build_info.buildTypeList"
          :key="item"
          :label="item"
          :value="item">
        </el-option>
      </el-select>
      </el-form-item>

      <el-form-item >
      <el-select v-model="build_info.version" @change="onChangeVersion" allow-create filterable placeholder="请选择或输入版本">
        <el-option
          v-for="item in build_info.versionList"
          :key="item"
          :label="item"
          :value="item">
        </el-option>
      </el-select>
      </el-form-item>

      <el-form-item v-if="build_info.platform==='android'" >
        <el-checkbox v-model="build_info.regression" @change="onChangeVersion">回归包</el-checkbox>
      </el-form-item>

      <el-form-item v-if="build_info.app==='陆国际'" >
        <el-checkbox v-model="build_info.is_need_upload_pgy" >上传蒲公英</el-checkbox>
      </el-form-item>

      <el-button type="success" :title="completeBuildInfo?'点击展开打包job的详细参数':'请先从左至右依次设置打包所需的配置'" @click="openBuildParams" :disabled="!completeBuildInfo">{{activeNames==='1'?'收起配置参数':'展开配置参数'}}</el-button>
      <el-button type="primary" :title="completeBuildParam?'点击开始打包':'请先从左至右依次设置打包所需的配置,并确认打包平台配置了对应的打包job'" @click="startBuildWarp" :disabled="!completeBuildParam">开始构建</el-button>
    </el-form>

      <el-collapse :class="{ detailParams: !completeBuildParam }" accordion :value="activeNames">
        <el-collapse-item name="1">
          <!--<template slot="title">-->
            <!--<label style="font-weight: 600">点击配置详细构建参数</label>-->
          <!--</template>-->

          <el-form id="detail-form" :inline="false"  ref="form_detail" label-width="12%">
            <el-form-item v-for="field in detailParams" :label="field.name" :key="field.name">
              <el-input v-if="field.type==='StringParameterDefinition'"
                        style="width: 28%; vertical-align: top"
                        :disabled="field.disable"
                        v-model="field.defaultParameterValue.value"></el-input>

              <el-select v-if="field.type==='ChoiceParameterDefinition'"
                         style="width: 28%; vertical-align: top"
                         :disabled="field.disable"
                         v-model="field.defaultParameterValue.value" placeholder="请选择">
                <el-option
                  v-for="item in field.choices"
                  :key="item"
                  :label="item"
                  :value="item">
                </el-option>
              </el-select>

              <el-checkbox v-if="field.type==='BooleanParameterDefinition'"
                           style="width: 28%; vertical-align: top"
                           v-model="field.defaultParameterValue.value"></el-checkbox>

              <div style="display: inline-block; width: 60%">
                <i class="header-icon el-icon-info"></i>
                <label>{{field.description}}</label>
              </div>
            </el-form-item>

            <el-button style="margin-left: 12%" type="primary" @click="startBuildWarp">开始构建</el-button>
          </el-form>

        </el-collapse-item>
      </el-collapse>

  </div>
</template>

<script>
  import { createNamespacedHelpers } from 'vuex'
  const { mapGetters, mapActions } = createNamespacedHelpers('mobilebuild')

  export default {
    name: 'BuildParams',
    data () {
      return {
      }
    },
    created () {
      this.build_info.app = undefined
      this.getDistApps()
    },
    watch: {
    },
    computed: {
      completeBuildInfo () {
        const vm = this
        if (vm.build_info.app &&
          vm.build_info.bu &&
          vm.build_info.platform &&
          vm.build_info.type &&
          vm.build_info.version) {
          return true
        } else {
          return false
        }
      },
      completeBuildParam () {
        return this.completeBuildInfo && this.detailParamsSuccess
      },
      activeNames: {
        get () {
          return this.$store.state['mobilebuild'].activeNames
        },
        set (value) {
          this.$store.commit('mobilebuild/UPDATE_ACTIVE_NAMES', undefined)
        }
      },
      ...mapGetters({
        build_info: 'build_info',
        build_param: 'build_param',
        actionType: 'actionType',
        detailParamsSuccess: 'detailParamsSuccess'
      }),
      detailParams () {
        const params = this.build_param
        return params
      }
    },
    methods: {
      /**
       * app 改变, 重置bu,拉取buList
       */
      onChangeApp () {
        this.getDistBus()
      },
      /**
       * bu 改变, 重置platform,拉取platformList
       */
      onChangeBu () {
        this.getDistPlatforms()
      },
      /**
       * platform 改变, 重置type,拉取typeList
       */
      onChangePlatform () {
        this.getDistBuildTypeList()
      },
      /**
       * type 改变, 重置version,拉取versionList
       */
      onChangeBuildType () {
        this.getRecentBuildVersion()
      },
      /**
       * version 改变, 拉取buildParams
       */
      onChangeVersion () {
//        const {app, bu, platform, type, version} = this.build_info
//        if (app && bu && platform && type && version) {
//          this.getBuildParams()
//        }
        if (this.completeBuildInfo) {
          this.getBuildParams()
        }
      },
      openBuildParams () {
        let value = '1'
        if (this.activeNames === '1') {
          value = undefined
        }
        this.$store.commit('mobilebuild/UPDATE_ACTIVE_NAMES', value)
      },
      startBuildWarp () {
        this.startBuild(this.arguments).then((res) => {
          console.log(res)
          if (res) {
            this.$emit('startBuild')
          }
        })
      },
      ...mapActions({
        getBuildParams: 'getBuildParams',
        startBuild: 'startBuild',
        getRecentBuildVersion: 'getRecentBuildVersion',
        getDistApps: 'getDistApps',
        getDistBus: 'getDistBus',
        getDistPlatforms: 'getDistPlatforms',
        getDistBuildTypeList: 'getDistBuildTypeList'
      })
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style rel="stylesheet/scss" lang="scss" scoped>

.detailParams {
  display: none;
}

</style>
