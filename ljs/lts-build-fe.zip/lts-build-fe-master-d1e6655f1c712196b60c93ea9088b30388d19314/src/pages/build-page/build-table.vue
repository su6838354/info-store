<template>
  <lucommon-table ref="table" :url="url" >
    <template slot="filters" slot-scope="props">
      <el-form-item label="ID">
        <el-input v-model="props.searchData.id" ></el-input>
      </el-form-item>
      <el-form-item label="APP">
        <el-input v-model="props.searchData.APP" ></el-input>
      </el-form-item>
      <el-form-item label="BU">
        <el-input v-model="props.searchData.BU" ></el-input>
      </el-form-item>
      <el-form-item label="平台">
        <el-input v-model="props.searchData.platform" ></el-input>
      </el-form-item>
      <el-form-item label="版本">
        <el-input v-model="props.searchData.version" ></el-input>
      </el-form-item>
      <el-form-item label="类型">
        <el-input v-model="props.searchData.type" ></el-input>
      </el-form-item>
      <el-form-item label="构建人">
        <el-input v-model="props.searchData.user" ></el-input>
      </el-form-item>
        <!--<el-form-item label="活动区域">-->
          <!--<el-select v-model="searchData.region" placeholder="活动区域">-->
            <!--<el-option label="区域一" value="shanghai"></el-option>-->
            <!--<el-option label="区域二" value="beijing"></el-option>-->
          <!--</el-select>-->
        <!--</el-form-item>-->
    </template>

    <el-table-column
      prop="id"
      label="ID"
      key="id"
      min-width="60">
      <template slot-scope="scope">
        {{ scope.row.id }}
      </template>
    </el-table-column>

    <el-table-column
      prop="APP"
      label="APP"
      key="APP"
      min-width="60">
      <template slot-scope="scope">
        {{ scope.row.APP }}
      </template>
    </el-table-column>

    <el-table-column
      prop="BU"
      label="BU"
      key="BU"
      min-width="60">
      <template slot-scope="scope">
        {{ scope.row.BU }}
      </template>
    </el-table-column>

    <el-table-column
      prop="platform"
      label="平台"
      key="platform"
      min-width="60">
      <template slot-scope="scope">
        {{ scope.row.platform }}
      </template>
    </el-table-column>

    <el-table-column
      prop="version"
      label="版本"
      key="version"
      min-width="60">
      <template slot-scope="scope">
        {{ scope.row.version }}
      </template>
    </el-table-column>

    <el-table-column
      prop="type"
      label="类型"
      key="type"
      min-width="60">
      <template slot-scope="scope">
        {{ scope.row.type }}
      </template>
    </el-table-column>

    <el-table-column
      prop="create_time"
      label="开始时间"
      key="create_time"
      min-width="100">
      <template slot-scope="scope">
        {{ scope.row.create_time }}
      </template>
    </el-table-column>

    <el-table-column
      prop="during"
      label="耗时"
      key="during"
      min-width="60">
      <template slot-scope="scope">
        {{ scope.row.during_formated }}
      </template>
    </el-table-column>

    <el-table-column
      prop="status_enum"
      label="状态"
      key="status_enum"
      min-width="60">
      <template slot-scope="scope">
        <el-tag :type="scope.row.status_enum.style" >{{scope.row.status_enum.desc }}</el-tag>
      </template>
    </el-table-column>

    <el-table-column
      prop="user"
      label="构建人"
      key="user"
      min-width="60">
      <template slot-scope="scope">
        {{scope.row.user}}
      </template>
    </el-table-column>

    <el-table-column
      label="操作"
      min-width="100">
      <template slot-scope="scope">
        <el-tooltip content="查看jenkins" placement="top">
          <el-button type="info" @click="openWindow(scope.row.jenkins_url)" icon="el-icon-info"></el-button>
        </el-tooltip>
        <el-tooltip v-if="scope.row.status!==0" content="重构" placement="top">
          <el-button type="warning" icon="el-icon-refresh" @click="toRebuild(scope.row)"></el-button>
        </el-tooltip>
        <el-tooltip v-if="scope.row.status===0" content="停止" placement="top">
          <el-button type="danger" @click="stopBuildWarp(scope.row.id)" icon="el-icon-close"></el-button>
        </el-tooltip>
      </template>
    </el-table-column>

  </lucommon-table>
</template>

<script>
  import lucommonTable from '../../components/lucommon-table'
  import { api } from '../../api/const'
  import { createNamespacedHelpers } from 'vuex'
  const { mapActions } = createNamespacedHelpers('mobilebuild')

  export default {
    name: 'BuildTable',
    data () {
      return {
        formInline: {
          user: '',
          region: ''
        }
      }
    },
    created () {
//      this.getData()
    },
    computed: {
      url () {
        return api.BUILD.GET_BUILD_INFO_DATA
      }
//      ...mapGetters({
//        rawData: 'build_list',
//        pagination: 'pagination',
//        loading: 'loading'
//      })
    },
    methods: {
      openWindow (url) {
        window.open(url)
      },
      stopBuildWarp (buildId) {
        this.stopBuild(buildId).then(() => {
          this.$refs['table'].fetchData()
        })
      },
      ...mapActions({
//        getData: 'getBuildList'，
        stopBuild: 'stopBuild',
        toRebuild: 'toRebuild'
      })
    },
    components: {
      lucommonTable
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>


</style>
<style>

</style>
