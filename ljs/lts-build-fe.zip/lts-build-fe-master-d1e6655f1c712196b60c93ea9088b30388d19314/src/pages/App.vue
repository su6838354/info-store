<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>
<script>
  export default {
    name: 'app',
    components: {
    }
  }
</script>

<style scope>
  #app {
    height: 100%;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    /*text-align: center;*/
    color: #2c3e50;
  }

  #app .el-container{
    min-height: 100%;
  }

  html{
    height: 100%;
  }

  body{
    height: 100%;
    margin: 0;
    font-family: Lato,Helvetica,Arial,sans-serif;
  }
  a{
    color: #16a085;
  }
  ::-webkit-scrollbar{
    width: 6px;
    height: 10px;
    background-color: #f5f5f5;
  }

  ::-webkit-scrollbar-track{
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
  }

  ::-webkit-scrollbar-thumb{
    border-radius: 10px;
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
    background-color: #555;
  }

  .el-tag--info {
    background-color: rgba(103, 194, 58, .1) !important;
    border-color: rgba(103, 194, 58, .2) !important;
    color: #67c23a !important;
  }

  .fe-pointer {
    cursor: pointer;
  }

</style>
