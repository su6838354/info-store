<template>
    <el-container direction="vertical">
      <mobile-header></mobile-header>
      <el-main>
        <breadcrumb class="breadcrumb-container"></breadcrumb>
        <transition name="fade">
          <router-view></router-view>
        </transition>
      </el-main>
      <el-footer id="mobile-footer">
        <mobile-footer></mobile-footer>
      </el-footer>
    </el-container>
</template>
<script>
//  import mcHeader from '../components/mc-header.vue'
//  import mcFooter from '../components/mc-footer.vue'
  import mobileHeader from '../../components/mobile-header.vue'
  import mobileFooter from '../../components/mobile-footer.vue'
  import Breadcrumb from '../../components/bread-crumb/index.vue'
  export default {
    name: 'layout',
    components: {
      mobileHeader,
      mobileFooter,
      Breadcrumb
    }
  }
</script>

<style scope>
  #mobile-footer{
    height: inherit!important;
    background-color: #eee;
    margin-top: 3rem;
  }

</style>
