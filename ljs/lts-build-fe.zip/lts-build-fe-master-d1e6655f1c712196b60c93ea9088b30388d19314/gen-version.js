/**
 * Created by test on 17-10-16.
 */

const rf=require("fs");
const cheerio = require('cheerio');

const data=rf.readFileSync("./dist/index.html","utf-8");

const $ = cheerio.load(data);
const scripts = $('script');
const src = $(scripts[scripts.length-1]).attr('src');
const version = src.substr(src.indexOf('app.') + 4, src.length-src.indexOf('app.')-7)

console.log(version);

rf.createWriteStream('./dist/.version');
rf.writeFile('./dist/.version', version,  function(err) {
    if (err) {
        return console.error(err);
    }
    console.log("数据写入成功！");
})
