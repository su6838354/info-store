export default {
  "projects": [

  ],
  "headers": {
    "data": {
      "menuList": [
        {
          "text" : "Dashboard",
          "href" : "http://lujs.cn/lts/mc/dashboard/",
          "active" : true
        },
        {
          "text" : "工作台",
          "href" : "http://lujs.cn/lts/mc/"
        },
        {
          "text" : "打包系统",
          "href" : "/lts/build/view/mobile/package",
          "list" :[
            {
              "text": "首页",
              "href": "/lts/build/view/mobile/package/index"
            },
            {
              "text": "构建",
              "href": "/lts/build/view/mobile/package/build"
            }
          ]
        },
        {
          "text" : "自动化测试",
          "href" : "http://lujs.cn/lts/mc/autotest/index.html"
        },
        {
          "text" : "云真机",
          "href" : "http://lujs.cn/lts/mc/stf/devices.html",
          "list" :[
            {
              "text": "远程调试",
              "href": "http://lujs.cn/lts/mc/stf/devices.html"
            },
            {
              "text": "多机查看",
              "href": "http://lujs.cn/lts/mc/stf/view.html"
            }
          ]
        },
        {
          "text" : "测试报告",
          "href" : "http://lujs.cn/lts/mc/autotest/tasks.html"
        },
        {
          "text" : "帮助",
          "href" : "http://lujs.cn/lts/lts-help/lu-mc/",
          "full" : true,
          "target_blank" : true
        }
      ],
      "userList":[
        {
          "divider":true
        },
        {
          "text" : "登出",
          "href" : "/user/logout",
          "method" : "logout"
        }
      ]
    },
    "code" : "0000",
    "message":"success"
  }
}
