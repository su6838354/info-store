'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://172.29.40.189:8989"'
}
