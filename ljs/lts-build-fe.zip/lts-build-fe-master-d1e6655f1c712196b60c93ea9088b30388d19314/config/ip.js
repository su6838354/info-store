/**
 * Created by test on 18-1-5.
 */

module.exports = function getIp() {
  try{
    const net = os.networkInterfaces();
    return net['eth0'][0].address
  }
  catch(e) {
    return 'localhost'
  }
}
